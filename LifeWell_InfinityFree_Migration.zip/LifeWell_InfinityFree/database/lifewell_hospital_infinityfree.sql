-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 17, 2025 at 10:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lifewell_hospital`
--

-- --------------------------------------------------------

--
-- Table structure for table `lw_activity_log`
--

CREATE TABLE `lw_activity_log` (
  `log_id` int(11) NOT NULL,
  `visit_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `action_type` enum('nurse_intake','forward_to_doctor','diagnosis','request_diagnostic','diagnostic_completed','prescribe','dispense','complete_visit') NOT NULL,
  `action_description` text DEFAULT NULL,
  `from_status` varchar(50) DEFAULT NULL,
  `to_status` varchar(50) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_activity_log`
--

INSERT INTO `lw_activity_log` (`log_id`, `visit_id`, `user_id`, `action_type`, `action_description`, `from_status`, `to_status`, `created_at`) VALUES
(1, 1, 7, 'nurse_intake', 'New visit created', NULL, 'nurse_intake', '2025-12-14 16:50:56'),
(2, 1, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-14 16:51:45'),
(3, 1, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-14 16:52:46'),
(4, 1, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-14 16:52:50'),
(5, 2, 7, 'nurse_intake', 'New visit created', NULL, 'nurse_intake', '2025-12-14 16:53:15'),
(6, 2, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-14 16:53:56'),
(7, 2, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-14 16:54:24'),
(8, 3, 7, 'nurse_intake', 'New visit created', NULL, 'nurse_intake', '2025-12-14 17:40:05'),
(9, 3, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-14 17:40:48'),
(10, 3, 6, 'diagnosis', 'Initial consultation completed', 'with_doctor', 'awaiting_diagnosis', '2025-12-14 17:41:53'),
(11, 4, 7, 'nurse_intake', 'New visit created', NULL, 'nurse_intake', '2025-12-14 18:25:58'),
(12, 4, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-14 18:26:28'),
(13, 4, 6, 'request_diagnostic', 'Diagnostic test requested', 'with_doctor', 'with_diagnostic', '2025-12-14 18:28:10'),
(14, 5, 7, 'nurse_intake', 'New visit created', NULL, 'nurse_intake', '2025-12-17 01:49:48'),
(15, 5, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-17 01:50:31'),
(16, 5, 6, 'request_diagnostic', 'Diagnostic test requested', 'with_doctor', 'with_diagnostic', '2025-12-17 02:17:06'),
(17, 5, 9, 'diagnostic_completed', 'All diagnostic tests completed and sent back to doctor', 'with_diagnostic', 'with_doctor', '2025-12-17 02:19:18'),
(18, 5, 6, 'diagnosis', 'Initial consultation completed - prescription pending', 'with_doctor', 'with_doctor', '2025-12-17 02:21:43'),
(19, 5, 6, 'request_diagnostic', 'Diagnostic test requested', 'with_doctor', 'with_diagnostic', '2025-12-17 02:23:03'),
(20, 5, 9, 'diagnostic_completed', 'All diagnostic tests completed and sent back to doctor', 'with_diagnostic', 'with_doctor', '2025-12-17 02:25:11'),
(21, 5, 6, 'diagnosis', 'Consultation completed - no further action needed', 'with_doctor', 'completed', '2025-12-17 02:38:07'),
(22, 6, 7, 'nurse_intake', 'New visit created', NULL, 'nurse_intake', '2025-12-17 02:46:50'),
(23, 6, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-17 02:49:35'),
(24, 6, 6, 'request_diagnostic', 'Diagnostic test requested', 'with_doctor', 'with_diagnostic', '2025-12-17 02:50:49'),
(25, 6, 9, 'diagnostic_completed', 'All diagnostic tests completed and sent back to doctor', 'with_diagnostic', 'with_doctor', '2025-12-17 02:52:11'),
(26, 6, 6, 'diagnosis', 'Initial consultation completed - prescription pending', 'with_doctor', 'with_doctor', '2025-12-17 02:52:47'),
(27, 6, 6, 'diagnosis', 'Consultation completed - no further action needed', 'with_doctor', 'completed', '2025-12-17 02:58:08'),
(28, 7, 7, 'nurse_intake', 'New visit created', NULL, 'nurse_intake', '2025-12-17 03:01:32'),
(29, 7, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-17 03:02:06'),
(30, 7, 6, 'request_diagnostic', 'Diagnostic test requested', 'with_doctor', 'with_diagnostic', '2025-12-17 03:11:58'),
(31, 7, 9, 'diagnostic_completed', 'All diagnostic tests completed and sent back to doctor', 'with_diagnostic', 'with_doctor', '2025-12-17 03:12:54'),
(32, 7, 6, 'request_diagnostic', 'Diagnostic test requested', 'with_doctor', 'with_diagnostic', '2025-12-17 03:37:26'),
(33, 7, 9, 'diagnostic_completed', 'All diagnostic tests completed and sent back to doctor', 'with_diagnostic', 'with_doctor', '2025-12-17 03:52:35'),
(34, 7, 6, 'request_diagnostic', 'Diagnostic test requested', 'with_doctor', 'with_diagnostic', '2025-12-17 03:53:29'),
(35, 7, 9, 'diagnostic_completed', 'All diagnostic tests completed and sent back to doctor', 'with_diagnostic', 'with_doctor', '2025-12-17 03:55:15'),
(36, 7, 6, 'diagnosis', 'Diagnostic results reviewed - prescription needed', 'with_diagnostic', 'with_doctor', '2025-12-17 16:11:19'),
(37, 7, 6, 'prescribe', 'Prescription created and forwarded to pharmacy', 'with_doctor', 'with_pharmacy', '2025-12-17 16:12:34'),
(38, 7, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:12:44'),
(39, 7, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:12:48'),
(40, 7, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:12:53'),
(41, 7, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:13:00'),
(42, 7, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:13:05'),
(43, 5, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:13:14'),
(44, 5, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:13:26'),
(45, 5, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:13:34'),
(46, 7, 10, 'dispense', 'Prescription dispensed and visit completed', 'with_pharmacy', 'completed', '2025-12-17 16:14:27'),
(47, 5, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:15:23'),
(48, 5, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 16:15:34'),
(49, 8, 7, 'nurse_intake', 'New visit created', NULL, 'nurse_intake', '2025-12-17 19:41:46'),
(50, 8, 7, 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor', '2025-12-17 19:42:22'),
(51, 8, 6, 'request_diagnostic', 'Diagnostic test requested', 'with_doctor', 'with_diagnostic', '2025-12-17 19:43:38'),
(52, 7, 6, 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed', '2025-12-17 19:43:48');

-- --------------------------------------------------------

--
-- Table structure for table `lw_consultations`
--

CREATE TABLE `lw_consultations` (
  `consultation_id` int(11) NOT NULL,
  `visit_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `diagnosis` text DEFAULT NULL,
  `treatment_plan` text DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `requires_diagnostic` tinyint(1) DEFAULT 0,
  `requires_prescription` tinyint(1) DEFAULT 0,
  `consultation_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('in_progress','awaiting_tests','completed') DEFAULT 'in_progress'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_consultations`
--

INSERT INTO `lw_consultations` (`consultation_id`, `visit_id`, `doctor_id`, `diagnosis`, `treatment_plan`, `notes`, `requires_diagnostic`, `requires_prescription`, `consultation_date`, `status`) VALUES
(1, 3, 6, 'Might have issues with stomach', 'give iv drip and rest', 'DO blood test', 1, 1, '2025-12-14 17:41:53', 'in_progress'),
(2, 4, 6, 'might be cornea', 'give medicine B66HE Hupogen', 'Observe after taking', 1, 1, '2025-12-14 18:28:10', 'awaiting_tests'),
(3, 5, 6, 'Might have a case of tonsil stones', 'Might have to recommend a breath mint', '', 1, 0, '2025-12-17 02:17:06', 'completed'),
(4, 5, 6, 'He needs help', 'Mouth wash', '', 0, 1, '2025-12-17 02:21:43', 'in_progress'),
(5, 5, 6, 'Err222', 'Ev1234', '', 1, 1, '2025-12-17 02:23:03', 'completed'),
(6, 5, 6, 'Hmm', 'Yikes', 'Nope', 0, 0, '2025-12-17 02:38:07', 'in_progress'),
(7, 6, 6, 'Might be anorexic', 'Give iron tablets', 'Doing a blood test, i Haemo count is low give iron', 1, 0, '2025-12-17 02:50:49', 'awaiting_tests'),
(8, 6, 6, 'qsqs', 'sss', '', 0, 1, '2025-12-17 02:52:47', 'in_progress'),
(9, 6, 6, 'ddn', 'ddh', '', 0, 0, '2025-12-17 02:58:08', 'in_progress'),
(10, 7, 6, 'T1', 'Diag T1', '', 1, 1, '2025-12-17 03:11:58', 'awaiting_tests'),
(11, 7, 6, 'test2', 'Anotherone', '', 1, 0, '2025-12-17 03:37:26', 'awaiting_tests'),
(12, 7, 6, 'n', 'n', '', 1, 0, '2025-12-17 03:53:29', 'completed'),
(13, 8, 6, 'con', 'slt', 'man', 1, 1, '2025-12-17 19:43:38', 'awaiting_tests');

-- --------------------------------------------------------

--
-- Table structure for table `lw_diagnostic_files`
--

CREATE TABLE `lw_diagnostic_files` (
  `file_id` int(11) NOT NULL,
  `result_id` int(11) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `file_path` varchar(500) NOT NULL,
  `file_type` varchar(50) NOT NULL,
  `file_size` int(11) NOT NULL,
  `uploaded_by` int(11) NOT NULL,
  `uploaded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_diagnostic_files`
--

INSERT INTO `lw_diagnostic_files` (`file_id`, `result_id`, `file_name`, `file_path`, `file_type`, `file_size`, `uploaded_by`, `uploaded_at`) VALUES
(1, 1, 'pairplot.png', 'uploads/diagnostic_files/diag_1_1765937958_69421326cd044.png', '0', 3107957, 9, '2025-12-17 02:19:18'),
(2, 2, 'log_20251217_011050.pdf', 'uploads/diagnostic_files/diag_2_1765938311_6942148712b22.pdf', '0', 129804, 9, '2025-12-17 02:25:11'),
(3, 2, 'pairplot.png', 'uploads/diagnostic_files/diag_2_1765938311_69421487147f2.png', '0', 3107957, 9, '2025-12-17 02:25:11'),
(4, 3, 'instructions-1.jpg', 'uploads/diagnostic_files/diag_3_1765939931_69421adb77c97.jpg', '0', 109085, 9, '2025-12-17 02:52:11'),
(5, 3, 'IoT Quiz 1_scheme.pdf', 'uploads/diagnostic_files/diag_3_1765939931_69421adb7a108.pdf', '0', 128105, 9, '2025-12-17 02:52:11'),
(6, 3, 'wallpNEWW.jpg', 'uploads/diagnostic_files/diag_3_1765939931_69421adb7b7b2.jpg', '0', 1332709, 9, '2025-12-17 02:52:11'),
(7, 4, 'CS 330_Lab 4 (1) (1).pdf', 'uploads/diagnostic_files/diag_4_1765941174_69421fb6477b2.pdf', '0', 528453, 9, '2025-12-17 03:12:54'),
(8, 4, 'vector1.jpg', 'uploads/diagnostic_files/diag_4_1765941174_69421fb64b7fb.jpg', '0', 109278, 9, '2025-12-17 03:12:54'),
(9, 5, 'inclass1-Nov-17.png', 'uploads/diagnostic_files/diag_5_1765943555_694229039d696.png', '0', 546878, 9, '2025-12-17 03:52:35'),
(10, 6, 'log_20251217_011010.pdf', 'uploads/diagnostic_files/diag_6_1765943715_694229a386caa.pdf', '0', 129684, 9, '2025-12-17 03:55:15');

-- --------------------------------------------------------

--
-- Table structure for table `lw_diagnostic_requests`
--

CREATE TABLE `lw_diagnostic_requests` (
  `request_id` int(11) NOT NULL,
  `visit_id` int(11) NOT NULL,
  `consultation_id` int(11) NOT NULL,
  `requested_by` int(11) NOT NULL,
  `assigned_to` int(11) DEFAULT NULL,
  `test_type` enum('blood_test','xray','ct_scan','mri','ultrasound','ecg','other') NOT NULL,
  `test_description` text NOT NULL,
  `urgency` enum('routine','urgent','stat') DEFAULT 'routine',
  `status` enum('pending','in_progress','completed','cancelled') DEFAULT 'pending',
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `completion_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_diagnostic_requests`
--

INSERT INTO `lw_diagnostic_requests` (`request_id`, `visit_id`, `consultation_id`, `requested_by`, `assigned_to`, `test_type`, `test_description`, `urgency`, `status`, `request_date`, `completion_date`) VALUES
(1, 4, 2, 6, 5, 'other', 'Diagnostic tests required as per consultation', 'routine', 'pending', '2025-12-14 18:28:10', NULL),
(2, 5, 3, 6, 9, 'other', 'Diagnostic tests required as per consultation', 'routine', 'completed', '2025-12-17 02:17:06', '2025-12-17 02:19:18'),
(3, 5, 5, 6, 9, 'other', 'Diagnostic tests required as per consultation', 'routine', 'completed', '2025-12-17 02:23:03', '2025-12-17 02:25:11'),
(4, 6, 7, 6, 9, 'other', 'Diagnostic tests required as per consultation', 'routine', 'completed', '2025-12-17 02:50:49', '2025-12-17 02:52:11'),
(5, 7, 10, 6, 9, 'other', 'Diagnostic tests required as per consultation', 'routine', 'completed', '2025-12-17 03:11:58', '2025-12-17 03:12:54'),
(6, 7, 11, 6, 9, 'other', 'Diagnostic tests required as per consultation', 'routine', 'completed', '2025-12-17 03:37:26', '2025-12-17 03:52:35'),
(7, 7, 12, 6, 9, 'other', 'Diagnostic tests required as per consultation', 'routine', 'completed', '2025-12-17 03:53:29', '2025-12-17 03:55:15'),
(8, 8, 13, 6, 9, 'other', 'Diagnostic tests required as per consultation', 'routine', 'in_progress', '2025-12-17 19:43:38', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `lw_diagnostic_results`
--

CREATE TABLE `lw_diagnostic_results` (
  `result_id` int(11) NOT NULL,
  `request_id` int(11) NOT NULL,
  `performed_by` int(11) NOT NULL,
  `result_summary` text DEFAULT NULL,
  `findings` text DEFAULT NULL,
  `recommendations` text DEFAULT NULL,
  `result_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_diagnostic_results`
--

INSERT INTO `lw_diagnostic_results` (`result_id`, `request_id`, `performed_by`, `result_summary`, `findings`, `recommendations`, `result_date`) VALUES
(1, 2, 9, 'YEs Xray doen he has tonsil stones eww', 'He has alot under his tongue yuck', 'He should brush daily and get a breath mint', '2025-12-17 02:19:18'),
(2, 3, 9, 'Yikes hes down', 'Nah bro', 'Wash your mouth', '2025-12-17 02:25:11'),
(3, 4, 9, 'Bro is skinney as meat', 'Very slim, Is he slim shady??', 'Give the boy some food', '2025-12-17 02:52:11'),
(4, 5, 9, 'R1', 'R1', 'R2', '2025-12-17 03:12:54'),
(5, 6, 9, 'ahhhha', 'Moeremoore shabiii kdidididi shabiiibibi kardi', 'AHaha', '2025-12-17 03:52:35'),
(6, 7, 9, 'please one more time', 'Hmmm', 'dhddk', '2025-12-17 03:55:15');

-- --------------------------------------------------------

--
-- Table structure for table `lw_notifications`
--

CREATE TABLE `lw_notifications` (
  `notification_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `visit_id` int(11) DEFAULT NULL,
  `title` varchar(200) NOT NULL,
  `message` text NOT NULL,
  `type` enum('info','success','warning','urgent') DEFAULT 'info',
  `is_read` tinyint(1) DEFAULT 0,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_notifications`
--

INSERT INTO `lw_notifications` (`notification_id`, `user_id`, `visit_id`, `title`, `message`, `type`, `is_read`, `created_at`) VALUES
(1, 3, 1, 'New Patient Referral', 'Patient Mickel Attah has been referred to you for consultation', 'info', 0, '2025-12-14 16:51:45'),
(2, 3, 1, 'New Patient Referral', 'Patient Mickel Attah has been referred to you for consultation', 'info', 0, '2025-12-14 16:52:46'),
(3, 3, 1, 'New Patient Referral', 'Patient Mickel Attah has been referred to you for consultation', 'info', 0, '2025-12-14 16:52:50'),
(4, 3, 2, 'New Patient Referral', 'Patient Mickel Attah has been referred to you for consultation', 'info', 0, '2025-12-14 16:53:56'),
(5, 3, 2, 'New Patient Referral', 'Patient Mickel Attah has been referred to you for consultation', 'info', 0, '2025-12-14 16:54:24'),
(6, 6, 3, 'New Patient Referral', 'Patient Mickel Attah has been referred to you for consultation', 'info', 0, '2025-12-14 17:40:48'),
(7, 6, 4, 'New Patient Referral', 'Patient Ahmed Sangurah has been referred to you for consultation', 'info', 0, '2025-12-14 18:26:28'),
(8, 5, 4, 'New Diagnostic Request', 'Diagnostic test requested for patient: Ahmed Sangurah', 'info', 0, '2025-12-14 18:28:10'),
(9, 6, 5, 'New Patient Referral', 'Patient Samuel Mensah has been referred to you for consultation', 'info', 0, '2025-12-17 01:50:31'),
(10, 9, 5, 'New Diagnostic Request', 'Diagnostic test requested for patient: Samuel Mensah', 'info', 0, '2025-12-17 02:17:06'),
(11, 6, 5, 'Diagnostic Results Ready', 'All diagnostic tests completed for patient: Samuel Mensah', 'success', 0, '2025-12-17 02:19:18'),
(12, 9, 5, 'New Diagnostic Request', 'Diagnostic test requested for patient: Samuel Mensah', 'info', 0, '2025-12-17 02:23:03'),
(13, 6, 5, 'Diagnostic Results Ready', 'All diagnostic tests completed for patient: Samuel Mensah', 'success', 0, '2025-12-17 02:25:11'),
(14, 6, 6, 'New Patient Referral', 'Patient Ahmed Sangurah has been referred to you for consultation', 'info', 0, '2025-12-17 02:49:35'),
(15, 9, 6, 'New Diagnostic Request', 'Diagnostic test requested for patient: Ahmed Sangurah', 'info', 0, '2025-12-17 02:50:49'),
(16, 6, 6, 'Diagnostic Results Ready', 'All diagnostic tests completed for patient: Ahmed Sangurah', 'success', 0, '2025-12-17 02:52:11'),
(17, 6, 7, 'New Patient Referral', 'Patient Rasputin Ral has been referred to you for consultation', 'info', 0, '2025-12-17 03:02:06'),
(18, 9, 7, 'New Diagnostic Request', 'Diagnostic test requested for patient: Rasputin Ral', 'info', 0, '2025-12-17 03:11:58'),
(19, 6, 7, 'Diagnostic Results Ready', 'All diagnostic tests completed for patient: Rasputin Ral', 'success', 0, '2025-12-17 03:12:54'),
(20, 9, 7, 'New Diagnostic Request', 'Diagnostic test requested for patient: Rasputin Ral', 'info', 0, '2025-12-17 03:37:26'),
(21, 6, 7, 'Diagnostic Results Ready', 'All diagnostic tests completed for patient: Rasputin Ral', 'success', 0, '2025-12-17 03:52:35'),
(22, 9, 7, 'New Diagnostic Request', 'Diagnostic test requested for patient: Rasputin Ral', 'info', 0, '2025-12-17 03:53:29'),
(23, 6, 7, 'Diagnostic Results Ready', 'All diagnostic tests completed for patient: Rasputin Ral', 'success', 0, '2025-12-17 03:55:15'),
(24, 10, 7, 'New Prescription', 'Prescription ready for dispensing: Rasputin Ral', 'info', 0, '2025-12-17 16:12:34'),
(25, 6, 8, 'New Patient Referral', 'Patient Mickel Attah has been referred to you for consultation', 'info', 0, '2025-12-17 19:42:22'),
(26, 9, 8, 'New Diagnostic Request', 'Diagnostic test requested for patient: Mickel Attah', 'info', 0, '2025-12-17 19:43:38');

-- --------------------------------------------------------

--
-- Table structure for table `lw_patients`
--

CREATE TABLE `lw_patients` (
  `patient_id` int(11) NOT NULL,
  `patient_code` varchar(20) NOT NULL,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` enum('Male','Female','Other') NOT NULL,
  `phone_number` varchar(20) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `blood_group` varchar(5) DEFAULT NULL,
  `allergies` text DEFAULT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `emergency_contact_phone` varchar(20) DEFAULT NULL,
  `medical_history` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_patients`
--

INSERT INTO `lw_patients` (`patient_id`, `patient_code`, `first_name`, `last_name`, `date_of_birth`, `gender`, `phone_number`, `email`, `address`, `blood_group`, `allergies`, `emergency_contact_name`, `emergency_contact_phone`, `medical_history`, `created_at`, `updated_at`) VALUES
(1, 'PAT001', 'Samuel', 'Mensah', '1990-05-15', 'Male', '0246789012', 'samuel.mensah@email.com', 'Accra, Ghana', 'O+', NULL, NULL, NULL, NULL, '2025-12-14 15:51:06', '2025-12-14 15:51:06'),
(2, 'PAT00002', 'Mickel', 'Attah', '2004-05-12', 'Male', '0201952455', 'JB@gmail.com', 'Greater Accra Region, Tema', 'A+', 'None', 'David Orhin', '0201952144', 'Has a history Of Taking medicing, Weight - 70kg, Height 1.8. Has stomach pain', '2025-12-14 16:50:32', '2025-12-14 16:50:32'),
(3, 'PAT00003', 'Ahmed', 'Sangurah', '2000-12-10', 'Male', '0201954332', 'MasterBradHoe@gmail.com', 'Greater Accra Region, Tema', 'B-', 'Dust, Mites', 'David Orhin', '0201952155', 'as a history of getting spasms', '2025-12-14 18:25:38', '2025-12-14 18:25:38'),
(4, 'PAT00004', 'Rasputin', 'Ral', '2000-04-04', 'Male', '0112234895', 'JBw@gmail.com', 'Greater Accra Region, Tema', 'O-', 'Nuts', 'Daniel', '0201952155', '', '2025-12-17 03:01:17', '2025-12-17 03:01:17');

-- --------------------------------------------------------

--
-- Table structure for table `lw_patient_visits`
--

CREATE TABLE `lw_patient_visits` (
  `visit_id` int(11) NOT NULL,
  `patient_id` int(11) NOT NULL,
  `visit_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `visit_status` enum('nurse_intake','with_doctor','awaiting_diagnosis','with_diagnostic','awaiting_prescription','with_pharmacy','completed','cancelled') DEFAULT 'nurse_intake',
  `current_handler_id` int(11) DEFAULT NULL,
  `priority` enum('normal','urgent','emergency') DEFAULT 'normal',
  `chief_complaint` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_patient_visits`
--

INSERT INTO `lw_patient_visits` (`visit_id`, `patient_id`, `visit_date`, `visit_status`, `current_handler_id`, `priority`, `chief_complaint`, `created_at`, `updated_at`) VALUES
(1, 2, '2025-12-14 16:50:56', 'with_doctor', 3, 'normal', 'Has headache', '2025-12-14 16:50:56', '2025-12-14 16:51:45'),
(2, 2, '2025-12-14 16:53:15', 'with_doctor', 3, 'emergency', 'Looks plae', '2025-12-14 16:53:15', '2025-12-14 16:53:56'),
(3, 2, '2025-12-14 17:40:05', 'awaiting_diagnosis', 6, 'urgent', 'He is vomitting', '2025-12-14 17:40:05', '2025-12-14 17:41:53'),
(4, 3, '2025-12-14 18:25:58', 'with_diagnostic', 5, 'normal', 'Eyes hurt', '2025-12-14 18:25:58', '2025-12-14 18:28:10'),
(5, 1, '2025-12-17 01:49:48', 'completed', 6, 'emergency', 'Mouth is Smelly', '2025-12-17 01:49:48', '2025-12-17 02:38:07'),
(6, 3, '2025-12-17 02:46:50', 'completed', 6, 'urgent', 'Lean body Looks Anorexic', '2025-12-17 02:46:50', '2025-12-17 02:58:08'),
(7, 4, '2025-12-17 03:01:32', 'completed', 10, 'urgent', 'Chest hurt', '2025-12-17 03:01:32', '2025-12-17 16:12:44'),
(8, 2, '2025-12-17 19:41:46', 'with_diagnostic', 9, 'urgent', 'Stomach ache', '2025-12-17 19:41:46', '2025-12-17 19:43:38');

-- --------------------------------------------------------

--
-- Table structure for table `lw_prescriptions`
--

CREATE TABLE `lw_prescriptions` (
  `prescription_id` int(11) NOT NULL,
  `visit_id` int(11) NOT NULL,
  `consultation_id` int(11) NOT NULL,
  `doctor_id` int(11) NOT NULL,
  `pharmacist_id` int(11) DEFAULT NULL,
  `prescription_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('pending','dispensed','cancelled') DEFAULT 'pending',
  `notes` text DEFAULT NULL,
  `dispensed_date` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_prescriptions`
--

INSERT INTO `lw_prescriptions` (`prescription_id`, `visit_id`, `consultation_id`, `doctor_id`, `pharmacist_id`, `prescription_date`, `status`, `notes`, `dispensed_date`) VALUES
(1, 7, 12, 6, 10, '2025-12-17 16:12:34', 'dispensed', 'Please add additional charges', '2025-12-17 16:14:27');

-- --------------------------------------------------------

--
-- Table structure for table `lw_prescription_items`
--

CREATE TABLE `lw_prescription_items` (
  `item_id` int(11) NOT NULL,
  `prescription_id` int(11) NOT NULL,
  `medication_name` varchar(200) NOT NULL,
  `dosage` varchar(100) NOT NULL,
  `frequency` varchar(100) NOT NULL,
  `duration` varchar(100) NOT NULL,
  `quantity` int(11) NOT NULL,
  `instructions` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_prescription_items`
--

INSERT INTO `lw_prescription_items` (`item_id`, `prescription_id`, `medication_name`, `dosage`, `frequency`, `duration`, `quantity`, `instructions`) VALUES
(1, 1, 'Duraphan', '200', 'Once Daily', '8 days', 4, 'Before Meals');

-- --------------------------------------------------------

--
-- Table structure for table `lw_users`
--

CREATE TABLE `lw_users` (
  `user_id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `role` enum('nurse','doctor','pharmacist','diagnostic','admin') NOT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `theme_preference` enum('light','dark') DEFAULT 'light',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `is_active` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_users`
--

INSERT INTO `lw_users` (`user_id`, `username`, `email`, `password_hash`, `full_name`, `phone_number`, `role`, `profile_image`, `theme_preference`, `created_at`, `updated_at`, `is_active`) VALUES
(1, 'admin', 'admin@lifewell.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', '0501234567', 'admin', NULL, 'light', '2025-12-14 15:51:06', '2025-12-14 15:51:06', 1),
(2, 'nurse_jane', 'jane.nurse@lifewell.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Jane Doe', '0502345678', 'nurse', NULL, 'light', '2025-12-14 15:51:06', '2025-12-14 15:51:06', 1),
(3, 'dr_smith', 'smith.doctor@lifewell.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Dr. John Smith', '0503456789', 'doctor', NULL, 'light', '2025-12-14 15:51:06', '2025-12-14 15:51:06', 1),
(4, 'pharm_mary', 'mary.pharm@lifewell.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Mary Johnson', '0504567890', 'pharmacist', NULL, 'light', '2025-12-14 15:51:06', '2025-12-14 15:51:06', 1),
(5, 'diag_mike', 'mike.lab@lifewell.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Mike Williams', '0505678901', 'diagnostic', NULL, 'light', '2025-12-14 15:51:06', '2025-12-14 15:51:06', 1),
(6, 'Orhin', 'davidorhin@ashesi.edu.gh', '$2y$10$lKbtRwiDZbyE.8Q8o//O2.LnEO/NL5RIuDMKHpuKf64CgU2cBi6U2', 'David', '0201952155', 'doctor', NULL, 'light', '2025-12-14 16:43:56', '2025-12-14 16:52:14', 1),
(7, 'KimJUll', 'KJ@gmail.com', '$2y$10$LbJwf8IhSaqi7FoMJbV0VuHdaUjjTfkS.7jSBnNBiI8/H/krNGE4e', 'MiniKim Manjo', '0201872653', 'nurse', NULL, 'dark', '2025-12-14 16:47:34', '2025-12-17 01:48:41', 1),
(8, 'house_MD', 'MJR@gmail.com', '$2y$10$bJH8qVkgMAZoLUogjJW2ROY3IDWpGkG.XIPGas1bsnTDx6RiPSOlq', 'Mark Dohene', '0208874532', 'doctor', NULL, 'light', '2025-12-14 16:55:35', '2025-12-16 23:06:00', 1),
(9, 'Dsmith', 'FI@gmail.com', '$2y$10$uMT06RY3vSO9nFFH6Ulrve/s.z7MiW0qHMmUuxQ3x.7WKEEza9pr2', 'Daniel Smith', '8830247438', 'diagnostic', NULL, 'light', '2025-12-14 17:24:55', '2025-12-14 17:24:55', 1),
(10, 'Ptest', 'ptest@gmail.com', '$2y$10$bFWbjvEw1U.K2dvoapFjb.YsVwS1Ov.zOzxVNoPWepAdZiAAIx1QS', 'Pahram test', '0384959384', 'pharmacist', NULL, 'dark', '2025-12-14 17:48:51', '2025-12-17 16:14:45', 1),
(11, 'Admintest', 'videpi9798@lesotica.com', '$2y$10$dRjp8zFXGAvGP3Y0ZnoY4eNGHs39VjsGQ4jZZBeO9EWwUMqNCZ4Zq', 'Fui Atuzamah', '0330489203', 'admin', NULL, 'light', '2025-12-14 17:57:03', '2025-12-14 17:57:03', 1),
(12, 'fulkanHH', 'HF@gmail.com', '$2y$10$boPAbGOTSWinqq8EtN48Eucs1A78tW21Nk1yb2u4mRpIfehUklepy', 'Hamad Fulkan', '0274485158', 'doctor', NULL, 'light', '2025-12-17 01:13:13', '2025-12-17 01:13:24', 0);

-- --------------------------------------------------------

--
-- Table structure for table `lw_vital_signs`
--

CREATE TABLE `lw_vital_signs` (
  `vital_id` int(11) NOT NULL,
  `visit_id` int(11) NOT NULL,
  `nurse_id` int(11) NOT NULL,
  `temperature` decimal(4,1) DEFAULT NULL,
  `blood_pressure_systolic` int(11) DEFAULT NULL,
  `blood_pressure_diastolic` int(11) DEFAULT NULL,
  `heart_rate` int(11) DEFAULT NULL,
  `respiratory_rate` int(11) DEFAULT NULL,
  `oxygen_saturation` decimal(4,1) DEFAULT NULL,
  `weight` decimal(5,2) DEFAULT NULL,
  `height` decimal(5,2) DEFAULT NULL,
  `bmi` decimal(4,2) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `recorded_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `lw_vital_signs`
--

INSERT INTO `lw_vital_signs` (`vital_id`, `visit_id`, `nurse_id`, `temperature`, `blood_pressure_systolic`, `blood_pressure_diastolic`, `heart_rate`, `respiratory_rate`, `oxygen_saturation`, `weight`, `height`, `bmi`, `notes`, `recorded_at`) VALUES
(1, 1, 7, 37.0, 119, 78, 88, 30, 98.5, 80.00, 190.20, 22.11, 'Looks very pale', '2025-12-14 16:51:45'),
(2, 1, 7, 37.0, 119, 78, 88, 30, 98.5, 80.00, 190.20, 22.11, 'Looks very pale', '2025-12-14 16:52:46'),
(3, 1, 7, 37.0, 119, 78, 88, 30, 98.5, 80.00, 190.20, 22.11, 'Looks very pale', '2025-12-14 16:52:50'),
(4, 2, 7, 37.0, 120, 80, 72, 19, 100.0, 68.00, 179.80, 21.03, 'N/A', '2025-12-14 16:53:56'),
(5, 2, 7, 37.0, 120, 80, 72, 19, 100.0, 68.00, 179.80, 21.03, 'N/A', '2025-12-14 16:54:24'),
(6, 3, 7, 36.9, 120, 90, 79, 30, 100.0, 90.48, 180.00, 27.93, 'Might need urgent care', '2025-12-14 17:40:48'),
(7, 4, 7, 37.0, 120, 79, 80, 20, 99.8, 90.00, 180.00, 27.78, 'none', '2025-12-14 18:26:28'),
(8, 5, 7, 38.0, 129, 79, 89, 20, 100.0, 80.00, 180.00, 24.69, '', '2025-12-17 01:50:31'),
(9, 6, 7, 39.0, 120, 79, 80, 20, 99.8, 90.00, 179.70, 27.87, '<script>alert(\\\'XSS\\\')</script>', '2025-12-17 02:49:35'),
(10, 7, 7, 38.0, 120, 88, 76, 20, 999.9, 89.99, 189.80, 24.98, '', '2025-12-17 03:02:06'),
(11, 8, 7, 37.0, 130, 80, 80, 17, 100.2, 80.00, 180.00, 24.69, '', '2025-12-17 19:42:22');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `lw_activity_log`
--
ALTER TABLE `lw_activity_log`
  ADD PRIMARY KEY (`log_id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_user` (`user_id`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `lw_consultations`
--
ALTER TABLE `lw_consultations`
  ADD PRIMARY KEY (`consultation_id`),
  ADD KEY `idx_visit` (`visit_id`),
  ADD KEY `idx_doctor` (`doctor_id`);

--
-- Indexes for table `lw_diagnostic_files`
--
ALTER TABLE `lw_diagnostic_files`
  ADD PRIMARY KEY (`file_id`),
  ADD KEY `uploaded_by` (`uploaded_by`),
  ADD KEY `idx_result` (`result_id`);

--
-- Indexes for table `lw_diagnostic_requests`
--
ALTER TABLE `lw_diagnostic_requests`
  ADD PRIMARY KEY (`request_id`),
  ADD KEY `consultation_id` (`consultation_id`),
  ADD KEY `requested_by` (`requested_by`),
  ADD KEY `assigned_to` (`assigned_to`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_visit` (`visit_id`);

--
-- Indexes for table `lw_diagnostic_results`
--
ALTER TABLE `lw_diagnostic_results`
  ADD PRIMARY KEY (`result_id`),
  ADD KEY `performed_by` (`performed_by`),
  ADD KEY `idx_request` (`request_id`);

--
-- Indexes for table `lw_notifications`
--
ALTER TABLE `lw_notifications`
  ADD PRIMARY KEY (`notification_id`),
  ADD KEY `visit_id` (`visit_id`),
  ADD KEY `idx_user_read` (`user_id`,`is_read`),
  ADD KEY `idx_created` (`created_at`);

--
-- Indexes for table `lw_patients`
--
ALTER TABLE `lw_patients`
  ADD PRIMARY KEY (`patient_id`),
  ADD UNIQUE KEY `patient_code` (`patient_code`),
  ADD KEY `idx_patient_code` (`patient_code`),
  ADD KEY `idx_name` (`last_name`,`first_name`);

--
-- Indexes for table `lw_patient_visits`
--
ALTER TABLE `lw_patient_visits`
  ADD PRIMARY KEY (`visit_id`),
  ADD KEY `patient_id` (`patient_id`),
  ADD KEY `current_handler_id` (`current_handler_id`),
  ADD KEY `idx_visit_status` (`visit_status`),
  ADD KEY `idx_visit_date` (`visit_date`);

--
-- Indexes for table `lw_prescriptions`
--
ALTER TABLE `lw_prescriptions`
  ADD PRIMARY KEY (`prescription_id`),
  ADD KEY `consultation_id` (`consultation_id`),
  ADD KEY `doctor_id` (`doctor_id`),
  ADD KEY `pharmacist_id` (`pharmacist_id`),
  ADD KEY `idx_status` (`status`),
  ADD KEY `idx_visit` (`visit_id`);

--
-- Indexes for table `lw_prescription_items`
--
ALTER TABLE `lw_prescription_items`
  ADD PRIMARY KEY (`item_id`),
  ADD KEY `idx_prescription` (`prescription_id`);

--
-- Indexes for table `lw_users`
--
ALTER TABLE `lw_users`
  ADD PRIMARY KEY (`user_id`),
  ADD UNIQUE KEY `username` (`username`),
  ADD UNIQUE KEY `email` (`email`),
  ADD KEY `idx_role` (`role`),
  ADD KEY `idx_email` (`email`);

--
-- Indexes for table `lw_vital_signs`
--
ALTER TABLE `lw_vital_signs`
  ADD PRIMARY KEY (`vital_id`),
  ADD KEY `nurse_id` (`nurse_id`),
  ADD KEY `idx_visit` (`visit_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `lw_activity_log`
--
ALTER TABLE `lw_activity_log`
  MODIFY `log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;

--
-- AUTO_INCREMENT for table `lw_consultations`
--
ALTER TABLE `lw_consultations`
  MODIFY `consultation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `lw_diagnostic_files`
--
ALTER TABLE `lw_diagnostic_files`
  MODIFY `file_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `lw_diagnostic_requests`
--
ALTER TABLE `lw_diagnostic_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `lw_diagnostic_results`
--
ALTER TABLE `lw_diagnostic_results`
  MODIFY `result_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `lw_notifications`
--
ALTER TABLE `lw_notifications`
  MODIFY `notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `lw_patients`
--
ALTER TABLE `lw_patients`
  MODIFY `patient_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `lw_patient_visits`
--
ALTER TABLE `lw_patient_visits`
  MODIFY `visit_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `lw_prescriptions`
--
ALTER TABLE `lw_prescriptions`
  MODIFY `prescription_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lw_prescription_items`
--
ALTER TABLE `lw_prescription_items`
  MODIFY `item_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `lw_users`
--
ALTER TABLE `lw_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `lw_vital_signs`
--
ALTER TABLE `lw_vital_signs`
  MODIFY `vital_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `lw_activity_log`
--
ALTER TABLE `lw_activity_log`
  ADD CONSTRAINT `lw_activity_log_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `lw_patient_visits` (`visit_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_activity_log_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `lw_users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `lw_consultations`
--
ALTER TABLE `lw_consultations`
  ADD CONSTRAINT `lw_consultations_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `lw_patient_visits` (`visit_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_consultations_ibfk_2` FOREIGN KEY (`doctor_id`) REFERENCES `lw_users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `lw_diagnostic_files`
--
ALTER TABLE `lw_diagnostic_files`
  ADD CONSTRAINT `lw_diagnostic_files_ibfk_1` FOREIGN KEY (`result_id`) REFERENCES `lw_diagnostic_results` (`result_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_diagnostic_files_ibfk_2` FOREIGN KEY (`uploaded_by`) REFERENCES `lw_users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `lw_diagnostic_requests`
--
ALTER TABLE `lw_diagnostic_requests`
  ADD CONSTRAINT `lw_diagnostic_requests_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `lw_patient_visits` (`visit_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_diagnostic_requests_ibfk_2` FOREIGN KEY (`consultation_id`) REFERENCES `lw_consultations` (`consultation_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_diagnostic_requests_ibfk_3` FOREIGN KEY (`requested_by`) REFERENCES `lw_users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_diagnostic_requests_ibfk_4` FOREIGN KEY (`assigned_to`) REFERENCES `lw_users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `lw_diagnostic_results`
--
ALTER TABLE `lw_diagnostic_results`
  ADD CONSTRAINT `lw_diagnostic_results_ibfk_1` FOREIGN KEY (`request_id`) REFERENCES `lw_diagnostic_requests` (`request_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_diagnostic_results_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `lw_users` (`user_id`) ON DELETE CASCADE;

--
-- Constraints for table `lw_notifications`
--
ALTER TABLE `lw_notifications`
  ADD CONSTRAINT `lw_notifications_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `lw_users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_notifications_ibfk_2` FOREIGN KEY (`visit_id`) REFERENCES `lw_patient_visits` (`visit_id`) ON DELETE SET NULL;

--
-- Constraints for table `lw_patient_visits`
--
ALTER TABLE `lw_patient_visits`
  ADD CONSTRAINT `lw_patient_visits_ibfk_1` FOREIGN KEY (`patient_id`) REFERENCES `lw_patients` (`patient_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_patient_visits_ibfk_2` FOREIGN KEY (`current_handler_id`) REFERENCES `lw_users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `lw_prescriptions`
--
ALTER TABLE `lw_prescriptions`
  ADD CONSTRAINT `lw_prescriptions_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `lw_patient_visits` (`visit_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_prescriptions_ibfk_2` FOREIGN KEY (`consultation_id`) REFERENCES `lw_consultations` (`consultation_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_prescriptions_ibfk_3` FOREIGN KEY (`doctor_id`) REFERENCES `lw_users` (`user_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_prescriptions_ibfk_4` FOREIGN KEY (`pharmacist_id`) REFERENCES `lw_users` (`user_id`) ON DELETE SET NULL;

--
-- Constraints for table `lw_prescription_items`
--
ALTER TABLE `lw_prescription_items`
  ADD CONSTRAINT `lw_prescription_items_ibfk_1` FOREIGN KEY (`prescription_id`) REFERENCES `lw_prescriptions` (`prescription_id`) ON DELETE CASCADE;

--
-- Constraints for table `lw_vital_signs`
--
ALTER TABLE `lw_vital_signs`
  ADD CONSTRAINT `lw_vital_signs_ibfk_1` FOREIGN KEY (`visit_id`) REFERENCES `lw_patient_visits` (`visit_id`) ON DELETE CASCADE,
  ADD CONSTRAINT `lw_vital_signs_ibfk_2` FOREIGN KEY (`nurse_id`) REFERENCES `lw_users` (`user_id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

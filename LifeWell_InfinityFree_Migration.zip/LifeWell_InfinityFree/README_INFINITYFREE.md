# LifeWell — InfinityFree deployment package

This package contains the application web root (`htdocs/`) and the SQL import file (`database/lifewell_hospital_infinityfree.sql`). It deliberately excludes the older Azure/online-host variant and diagnostic/debug test pages.

## Before uploading
1. In InfinityFree, create your hosting account and open **Control Panel → MySQL Databases**. Create a database and copy the exact MySQL hostname, database name, username, and password shown there. Do not assume the hostname is `localhost`.
2. Open `htdocs/config.php` and replace all four `REPLACE_WITH_INFINITYFREE_...` values with those exact values. Do not share or commit this file with real credentials.
3. In phpMyAdmin for that database, import `database/lifewell_hospital_infinityfree.sql`. If phpMyAdmin reports an error, save the exact error and line number; do not repeatedly import over a partly imported database.
4. Upload the *contents* of `htdocs/` into the site's `htdocs/` directory using the InfinityFree File Manager or FTP. Do not upload the outer `LifeWell_InfinityFree` folder itself.
5. Confirm `uploads/diagnostic_files/` exists. Test login, each role dashboard, create a test visit, upload a small JPG/PDF, and open/download that file.

## Important migration notes
- Database credentials are placeholders and must be configured by you.
- The SQL file retains the application's sample records. Existing diagnostic file records are mapped to relative paths. Existing files are included under `htdocs/uploads/diagnostic_files/`; any missing file must be uploaded again.
- New diagnostic uploads are stored using relative paths. `view_file.php` safely resolves only the stored filename inside the upload directory, which supports old Windows paths in migrated records without exposing filesystem paths.
- The `file_type` parameter binding has been corrected (the old code stored it as `0`).
- Developer debug/test endpoints have been excluded from the deployable web root.
- PHP errors are not displayed to visitors; check the InfinityFree error logs when diagnosing a problem.
- Shared hosting is not appropriate for real patient/medical records without a proper privacy, security, and compliance assessment. Use synthetic/demo data only for this student deployment.

## If the database connection fails
Check the four values in `config.php` against **MySQL Databases**. Common causes are using `localhost`, using the hosting login instead of the database username, or omitting the account prefix from the database name.

## Known limitations to test on InfinityFree
- Hosting providers enforce their own PHP upload/post limits; the app's 10 MB limit does not override server limits. If uploads fail, check `upload_max_filesize` and `post_max_size` available to the account and test with a smaller file.
- Some free hosts impose request/resource limits. The application has not been live-tested against your specific InfinityFree account or its current server configuration.

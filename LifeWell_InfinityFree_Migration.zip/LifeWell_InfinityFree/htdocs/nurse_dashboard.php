<?php
require_once 'config.php';
requireLogin();

if (!hasRole('nurse')) {
    header('Location: dashboard.php');
    exit();
}

$page_title = 'Nurse Dashboard';
$success = '';
$error = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'register_patient') {
    $patient_code = generatePatientCode($conn);
    $first_name = sanitize($_POST['first_name']);
    $last_name = sanitize($_POST['last_name']);
    $dob = sanitize($_POST['dob']);
    $gender = sanitize($_POST['gender']);
    $phone = sanitize($_POST['phone']);
    $email = sanitize($_POST['email']);
    $address = sanitize($_POST['address']);
    $blood_group = sanitize($_POST['blood_group']);
    $allergies = sanitize($_POST['allergies']);
    $emergency_name = sanitize($_POST['emergency_name']);
    $emergency_phone = sanitize($_POST['emergency_phone']);
    $medical_history = sanitize($_POST['medical_history']);
    
    $stmt = $conn->prepare("INSERT INTO lw_patients (patient_code, first_name, last_name, date_of_birth, gender, phone_number, email, address, blood_group, allergies, emergency_contact_name, emergency_contact_phone, medical_history) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssssssssss", $patient_code, $first_name, $last_name, $dob, $gender, $phone, $email, $address, $blood_group, $allergies, $emergency_name, $emergency_phone, $medical_history);
    
    if ($stmt->execute()) {
        $success = "Patient registered successfully! Patient Code: " . $patient_code;
    } else {
        $error = "Failed to register patient";
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_visit') {
    $patient_id = intval($_POST['patient_id']);
    $chief_complaint = sanitize($_POST['chief_complaint']);
    $priority = sanitize($_POST['priority']);
    
    $stmt = $conn->prepare("INSERT INTO lw_patient_visits (patient_id, visit_status, current_handler_id, priority, chief_complaint) VALUES (?, 'nurse_intake', ?, ?, ?)");
    $stmt->bind_param("iiss", $patient_id, $_SESSION['user_id'], $priority, $chief_complaint);
    
    if ($stmt->execute()) {
        $visit_id = $stmt->insert_id;
        logActivity($conn, $visit_id, $_SESSION['user_id'], 'nurse_intake', 'New visit created', null, 'nurse_intake');
        header('Location: nurse_dashboard.php?visit_id=' . $visit_id);
        exit();
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'record_vitals') {
    $visit_id = intval($_POST['visit_id']);
    $temp = floatval($_POST['temperature']);
    $bp_sys = intval($_POST['bp_systolic']);
    $bp_dia = intval($_POST['bp_diastolic']);
    $heart_rate = intval($_POST['heart_rate']);
    $resp_rate = intval($_POST['respiratory_rate']);
    $o2_sat = floatval($_POST['oxygen_saturation']);
    $weight = floatval($_POST['weight']);
    $height = floatval($_POST['height']);
    $bmi = $weight / (($height / 100) ** 2);
    $notes = sanitize($_POST['notes']);
    $selected_doctor_id = intval($_POST['doctor_id']);
    
    $stmt = $conn->prepare("INSERT INTO lw_vital_signs (visit_id, nurse_id, temperature, blood_pressure_systolic, blood_pressure_diastolic, heart_rate, respiratory_rate, oxygen_saturation, weight, height, bmi, notes) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iidiiiidddds", $visit_id, $_SESSION['user_id'], $temp, $bp_sys, $bp_dia, $heart_rate, $resp_rate, $o2_sat, $weight, $height, $bmi, $notes);
    
    if ($stmt->execute()) {
        if ($selected_doctor_id > 0) {
            $conn->query("UPDATE lw_patient_visits SET visit_status = 'with_doctor', current_handler_id = $selected_doctor_id WHERE visit_id = $visit_id");
            
            $patient_info = $conn->query("SELECT CONCAT(p.first_name, ' ', p.last_name) as name FROM lw_patients p JOIN lw_patient_visits v ON p.patient_id = v.patient_id WHERE v.visit_id = $visit_id")->fetch_assoc();
            createNotification($conn, $selected_doctor_id, $visit_id, 'New Patient Referral', 'Patient ' . $patient_info['name'] . ' has been referred to you for consultation', 'info');
            
            logActivity($conn, $visit_id, $_SESSION['user_id'], 'forward_to_doctor', 'Patient forwarded to doctor after vital signs recorded', 'nurse_intake', 'with_doctor');
            
            $success = "Vitals recorded and patient forwarded to doctor successfully!";
            header('Location: nurse_dashboard.php?success=vitals_recorded');
            exit(); 
        } else {
            $error = "Please select a doctor to forward the patient to.";
        }
    }
}
       

$active_visits = $conn->query("SELECT v.*, p.*, CONCAT(p.first_name, ' ', p.last_name) as patient_name FROM lw_patient_visits v JOIN lw_patients p ON v.patient_id = p.patient_id WHERE v.visit_status = 'nurse_intake' AND v.current_handler_id = {$_SESSION['user_id']} ORDER BY v.created_at DESC");


$all_patients = $conn->query("SELECT patient_id, patient_code, CONCAT(first_name, ' ', last_name) as name, phone_number FROM lw_patients ORDER BY created_at DESC");


$stats = [
    'todays_visits' => $conn->query("SELECT COUNT(*) as count FROM lw_patient_visits v WHERE DATE(v.visit_date) = CURDATE() AND v.current_handler_id = {$_SESSION['user_id']}")->fetch_assoc()['count'],
    'pending_intake' => $conn->query("SELECT COUNT(*) as count FROM lw_patient_visits WHERE visit_status = 'nurse_intake' AND current_handler_id = {$_SESSION['user_id']}")->fetch_assoc()['count'],
    'total_patients' => $conn->query("SELECT COUNT(*) as count FROM lw_patients")->fetch_assoc()['count']
];

include 'includes/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-label">Today's Visits</div>
        <div class="stat-value"><?php echo $stats['todays_visits']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Pending Intake</div>
        <div class="stat-value"><?php echo $stats['pending_intake']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Patients</div>
        <div class="stat-value"><?php echo $stats['total_patients']; ?></div>
    </div>
</div>

<?php if (isset($_GET['success'])): ?>
    <div class="alert alert-success">Vitals recorded and patient forwarded to doctor successfully!</div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Quick Actions</h2>
    </div>
    <div style="display: flex; gap: 15px; flex-wrap: wrap;">
        <button onclick="showModal('registerPatientModal')" class="btn btn-primary">Register New Patient</button>
        <button onclick="showModal('createVisitModal')" class="btn btn-primary">Create New Visit</button>
        <a href="patient_lookup.php" class="btn btn-secondary">Patient Lookup</a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Active Visits - Awaiting Vitals</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Patient Code</th>
                    <th>Patient Name</th>
                    <th>Age</th>
                    <th>Chief Complaint</th>
                    <th>Priority</th>
                    <th>Time</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($visit = $active_visits->fetch_assoc()): 
                    $age = date_diff(date_create($visit['date_of_birth']), date_create('now'))->y;
                ?>
                <tr>
                    <td><?php echo htmlspecialchars($visit['patient_code']); ?></td>
                    <td><?php echo htmlspecialchars($visit['patient_name']); ?></td>
                    <td><?php echo $age; ?> years</td>
                    <td><?php echo htmlspecialchars($visit['chief_complaint']); ?></td>
                    <td><span class="badge badge-<?php echo $visit['priority'] === 'emergency' ? 'danger' : ($visit['priority'] === 'urgent' ? 'warning' : 'info'); ?>"><?php echo ucfirst($visit['priority']); ?></span></td>
                    <td><?php echo date('h:i A', strtotime($visit['created_at'])); ?></td>
                    <td>
                        <button onclick="recordVitals(<?php echo $visit['visit_id']; ?>, '<?php echo htmlspecialchars($visit['patient_name']); ?>')" class="btn btn-primary">Record Vitals</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div id="registerPatientModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Register New Patient</h2>
            <button class="modal-close" onclick="closeModal('registerPatientModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="register_patient">
            <div class="form-group">
                <label>First Name *</label>
                <input type="text" name="first_name" required>
            </div>
            <div class="form-group">
                <label>Last Name *</label>
                <input type="text" name="last_name" required>
            </div>
            <div class="form-group">
                <label>Date of Birth *</label>
                <input type="date" name="dob" required>
            </div>
            <div class="form-group">
                <label>Gender *</label>
                <select name="gender" required>
                    <option value="Male">Male</option>
                    <option value="Female">Female</option>
                    <option value="Other">Other</option>
                </select>
            </div>
            <div class="form-group">
                <label>Phone Number *</label>
                <input type="tel" name="phone" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email">
            </div>
            <div class="form-group">
                <label>Address</label>
                <textarea name="address" rows="3"></textarea>
            </div>
            <div class="form-group">
                <label>Blood Group</label>
                <select name="blood_group">
                    <option value="">Select</option>
                    <option value="A+">A+</option>
                    <option value="A-">A-</option>
                    <option value="B+">B+</option>
                    <option value="B-">B-</option>
                    <option value="O+">O+</option>
                    <option value="O-">O-</option>
                    <option value="AB+">AB+</option>
                    <option value="AB-">AB-</option>
                </select>
            </div>
            <div class="form-group">
                <label>Allergies</label>
                <textarea name="allergies" rows="2"></textarea>
            </div>
            <div class="form-group">
                <label>Emergency Contact Name</label>
                <input type="text" name="emergency_name">
            </div>
            <div class="form-group">
                <label>Emergency Contact Phone</label>
                <input type="tel" name="emergency_phone">
            </div>
            <div class="form-group">
                <label>Medical History</label>
                <textarea name="medical_history" rows="4"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Register Patient</button>
        </form>
    </div>
</div>


<div id="createVisitModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Create New Visit</h2>
            <button class="modal-close" onclick="closeModal('createVisitModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="create_visit">
            <div class="form-group">
                <label>Select Patient *</label>
                <select name="patient_id" required>
                    <option value="">Select Patient</option>
                    <?php 
                    $all_patients->data_seek(0); // Reset pointer
                    while ($patient = $all_patients->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $patient['patient_id']; ?>">
                            <?php echo htmlspecialchars($patient['patient_code'] . ' - ' . $patient['name'] . ' (' . $patient['phone_number'] . ')'); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label>Chief Complaint *</label>
                <textarea name="chief_complaint" rows="3" required placeholder="Describe the patient's main complaint"></textarea>
            </div>
            <div class="form-group">
                <label>Priority *</label>
                <select name="priority" required>
                    <option value="normal">Normal</option>
                    <option value="urgent">Urgent</option>
                    <option value="emergency">Emergency</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Create Visit</button>
        </form>
    </div>
</div>


<div id="recordVitalsModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Record Vital Signs</h2>
            <button class="modal-close" onclick="closeModal('recordVitalsModal')">&times;</button>
        </div>
        <div id="vitalPatientInfo" style="background: var(--bg-tertiary); padding: 15px; border-radius: 8px; margin-bottom: 20px;"></div>
        <form method="POST">
            <input type="hidden" name="action" value="record_vitals">
            <input type="hidden" name="visit_id" id="vitalVisitId">
            
            <div class="form-group">
                <label>Assign to Doctor *</label>
                <select name="doctor_id" required>
                    <option value="">Select Doctor</option>
                    <?php 
                    // Fresh query 
                    $available_doctors = $conn->query("SELECT user_id, full_name FROM lw_users WHERE role = 'doctor' AND is_active = TRUE ORDER BY full_name");
                    while ($doctor = $available_doctors->fetch_assoc()): 
                    ?>
                        <option value="<?php echo $doctor['user_id']; ?>">
                            <?php echo htmlspecialchars($doctor['full_name']); ?>
                        </option>
                    <?php endwhile; ?>
                </select>
            </div>
            
            <div class="form-group">
                <label>Temperature (°C) *</label>
                <input type="number" step="0.1" name="temperature" required placeholder="36.5">
            </div>
            <div class="form-group">
                <label>Blood Pressure (mmHg) *</label>
                <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                    <input type="number" name="bp_systolic" required placeholder="Systolic (120)">
                    <input type="number" name="bp_diastolic" required placeholder="Diastolic (80)">
                </div>
            </div>
            <div class="form-group">
                <label>Heart Rate (bpm) *</label>
                <input type="number" name="heart_rate" required placeholder="72">
            </div>
            <div class="form-group">
                <label>Respiratory Rate (breaths/min) *</label>
                <input type="number" name="respiratory_rate" required placeholder="16">
            </div>
            <div class="form-group">
                <label>Oxygen Saturation (%) *</label>
                <input type="number" step="0.1" name="oxygen_saturation" required placeholder="98.5">
            </div>
            <div class="form-group">
                <label>Weight (kg) *</label>
                <input type="number" step="0.01" name="weight" required placeholder="70.5">
            </div>
            <div class="form-group">
                <label>Height (cm) *</label>
                <input type="number" step="0.1" name="height" required placeholder="175.5">
            </div>
            <div class="form-group">
                <label>Notes</label>
                <textarea name="notes" rows="3" placeholder="Additional observations..."></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Record & Forward to Selected Doctor</button>
        </form>
    </div>
</div>

<script>
function recordVitals(visitId, patientName) {
    document.getElementById('vitalVisitId').value = visitId;
    document.getElementById('vitalPatientInfo').innerHTML = '<strong>Patient:</strong> ' + patientName + '<br><strong>Visit ID:</strong> ' + visitId;
    showModal('recordVitalsModal');
}
</script>

</main>
</body>
</html>
<?php
require_once 'config.php';
requireLogin();


error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');

header('Content-Type: application/json');

if (!isset($_GET['consultation_id'])) {
    echo json_encode(['error' => 'Consultation ID required']);
    exit;
}

$consultation_id = intval($_GET['consultation_id']);


$consultation_query = "
    SELECT c.*, v.visit_id, CONCAT(p.first_name, ' ', p.last_name) as patient_name
    FROM lw_consultations c
    JOIN lw_patient_visits v ON c.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    WHERE c.consultation_id = ?
";

$stmt = $conn->prepare($consultation_query);
$stmt->bind_param("i", $consultation_id);
$stmt->execute();
$consultation = $stmt->get_result()->fetch_assoc();
$stmt->close();

if (!$consultation) {
    echo json_encode(['error' => 'Consultation not found', 'consultation_id' => $consultation_id]);
    exit;
}

// diagnostic requests and results
$results_query = "
    SELECT 
        dr.request_id,
        dr.test_type,
        dr.test_description,
        dr.status as request_status,
        dres.result_id,
        dres.result_summary,
        dres.findings,
        dres.recommendations,
        dres.result_date
    FROM lw_diagnostic_requests dr
    LEFT JOIN lw_diagnostic_results dres ON dr.request_id = dres.request_id
    WHERE dr.consultation_id = ?
    ORDER BY dr.request_date DESC
";

$stmt = $conn->prepare($results_query);
$stmt->bind_param("i", $consultation_id);
$stmt->execute();
$results_data = $stmt->get_result();
$stmt->close();

$results = [];
while ($row = $results_data->fetch_assoc()) {
   
    $files = [];
    if ($row['result_id']) {
        $files_query = "
            SELECT file_id, file_name, file_type, file_size
            FROM lw_diagnostic_files
            WHERE result_id = ?
            ORDER BY uploaded_at ASC
        ";
        $file_stmt = $conn->prepare($files_query);
        $file_stmt->bind_param("i", $row['result_id']);
        $file_stmt->execute();
        $files_result = $file_stmt->get_result();
        
        while ($file = $files_result->fetch_assoc()) {
            $files[] = [
                'file_id' => $file['file_id'],
                'file_name' => $file['file_name'],
                'file_type' => $file['file_type'],
                'file_size' => round($file['file_size'] / 1024, 2) . ' KB'
            ];
        }
        $file_stmt->close();
    }
    
    $results[] = [
        'request_id' => $row['request_id'],
        'test_type' => ucfirst(str_replace('_', ' ', $row['test_type'])),
        'test_description' => $row['test_description'] ?: 'N/A',
        'status' => $row['request_status'],
        'result_summary' => $row['result_summary'] ?: '',
        'findings' => $row['findings'] ?: '',
        'recommendations' => $row['recommendations'] ?: '',
        'result_date' => $row['result_date'] ? date('M d, Y h:i A', strtotime($row['result_date'])) : null,
        'files' => $files,
        'has_result' => ($row['result_id'] ? true : false)
    ];
}

$response = [
    'success' => true,
    'patient_name' => $consultation['patient_name'],
    'diagnosis' => $consultation['diagnosis'],
    'treatment_plan' => $consultation['treatment_plan'],
    'consultation_notes' => $consultation['notes'],
    'results' => $results,
    'total_results' => count($results)
];

echo json_encode($response, JSON_PRETTY_PRINT);
?>
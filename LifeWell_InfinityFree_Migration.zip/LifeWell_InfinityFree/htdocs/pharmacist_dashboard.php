<?php
require_once 'config.php';
requireLogin();

if (!hasRole('pharmacist')) {
    header('Location: dashboard.php');
    exit();
}

$page_title = 'Pharmacist Dashboard';
$success = '';
$error = '';

// Handle dispensing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'dispense') {
    $prescription_id = intval($_POST['prescription_id']);
    $visit_id = intval($_POST['visit_id']);
    
    $conn->query("UPDATE lw_prescriptions SET status = 'dispensed', pharmacist_id = {$_SESSION['user_id']}, dispensed_date = NOW() WHERE prescription_id = $prescription_id");
    $conn->query("UPDATE lw_patient_visits SET visit_status = 'completed' WHERE visit_id = $visit_id");
    
    logActivity($conn, $visit_id, $_SESSION['user_id'], 'dispense', 'Prescription dispensed and visit completed', 'with_pharmacy', 'completed');
    
    $success = "Prescription dispensed successfully!";
}


$pending_prescriptions = $conn->query("
    SELECT pr.*, v.visit_id, p.patient_code, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
           doc.full_name as doctor_name, c.diagnosis
    FROM lw_prescriptions pr
    JOIN lw_patient_visits v ON pr.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    JOIN lw_users doc ON pr.doctor_id = doc.user_id
    LEFT JOIN lw_consultations c ON pr.consultation_id = c.consultation_id
    WHERE pr.status = 'pending'
    ORDER BY pr.prescription_date DESC
");

// Get dispensed 
$dispensed_prescriptions = $conn->query("
    SELECT pr.*, p.patient_code, CONCAT(p.first_name, ' ', p.last_name) as patient_name
    FROM lw_prescriptions pr
    JOIN lw_patient_visits v ON pr.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    WHERE pr.status = 'dispensed' AND pr.pharmacist_id = {$_SESSION['user_id']}
    ORDER BY pr.dispensed_date DESC
    LIMIT 20
");

// Get stats
$stats = [
    'pending' => $conn->query("SELECT COUNT(*) as count FROM lw_prescriptions WHERE status = 'pending'")->fetch_assoc()['count'],
    'dispensed_today' => $conn->query("SELECT COUNT(*) as count FROM lw_prescriptions WHERE pharmacist_id = {$_SESSION['user_id']} AND DATE(dispensed_date) = CURDATE()")->fetch_assoc()['count'],
    'total_dispensed' => $conn->query("SELECT COUNT(*) as count FROM lw_prescriptions WHERE pharmacist_id = {$_SESSION['user_id']} AND status = 'dispensed'")->fetch_assoc()['count']
];

include 'includes/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-label">Pending Prescriptions</div>
        <div class="stat-value"><?php echo $stats['pending']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Dispensed Today</div>
        <div class="stat-value"><?php echo $stats['dispensed_today']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Dispensed</div>
        <div class="stat-value"><?php echo $stats['total_dispensed']; ?></div>
    </div>
</div>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Pending Prescriptions</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Patient</th>
                    <th>Doctor</th>
                    <th>Diagnosis</th>
                    <th>Prescription Date</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($prescription = $pending_prescriptions->fetch_assoc()): ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($prescription['patient_name']); ?></strong><br>
                        <small><?php echo htmlspecialchars($prescription['patient_code']); ?></small>
                    </td>
                    <td><?php echo htmlspecialchars($prescription['doctor_name']); ?></td>
                    <td><?php echo htmlspecialchars($prescription['diagnosis']); ?></td>
                    <td><?php echo date('M d, Y h:i A', strtotime($prescription['prescription_date'])); ?></td>
                    <td>
                        <button onclick="viewPrescription(<?php echo $prescription['prescription_id']; ?>, <?php echo $prescription['visit_id']; ?>)" class="btn btn-primary">View & Dispense</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Recently Dispensed</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Patient</th>
                    <th>Dispensed Date</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($prescription = $dispensed_prescriptions->fetch_assoc()): ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($prescription['patient_name']); ?></strong><br>
                        <small><?php echo htmlspecialchars($prescription['patient_code']); ?></small>
                    </td>
                    <td><?php echo date('M d, Y h:i A', strtotime($prescription['dispensed_date'])); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Prescription  -->
<div id="prescriptionModal" class="modal">
    <div class="modal-content" style="max-width: 800px;">
        <div class="modal-header">
            <h2>Prescription Details</h2>
            <button class="modal-close" onclick="closeModal('prescriptionModal')">&times;</button>
        </div>
        <div id="prescriptionDetails"></div>
    </div>
</div>

<script>
function viewPrescription(prescriptionId, visitId) {
    fetch('get_prescription_details.php?prescription_id=' + prescriptionId)
        .then(res => res.json())
        .then(data => {
            let itemsHtml = '';
            data.items.forEach(item => {
                itemsHtml += `
                    <tr>
                        <td><strong>${item.medication_name}</strong></td>
                        <td>${item.dosage}</td>
                        <td>${item.frequency}</td>
                        <td>${item.duration}</td>
                        <td>${item.quantity}</td>
                        <td>${item.instructions || '-'}</td>
                    </tr>
                `;
            });
            
            const html = `
                <div style="background: var(--bg-tertiary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                    <p><strong>Patient:</strong> ${data.patient_name}</p>
                    <p><strong>Doctor:</strong> ${data.doctor_name}</p>
                    <p><strong>Date:</strong> ${data.prescription_date}</p>
                    ${data.notes ? '<p><strong>Notes:</strong> ' + data.notes + '</p>' : ''}
                </div>
                <h3 style="margin-bottom: 15px;">Medications</h3>
                <div class="table-container" style="margin-bottom: 20px;">
                    <table>
                        <thead>
                            <tr>
                                <th>Medication</th>
                                <th>Dosage</th>
                                <th>Frequency</th>
                                <th>Duration</th>
                                <th>Quantity</th>
                                <th>Instructions</th>
                            </tr>
                        </thead>
                        <tbody>
                            ${itemsHtml}
                        </tbody>
                    </table>
                </div>
                <form method="POST">
                    <input type="hidden" name="action" value="dispense">
                    <input type="hidden" name="prescription_id" value="${prescriptionId}">
                    <input type="hidden" name="visit_id" value="${visitId}">
                    <button type="submit" class="btn btn-primary">Dispense Prescription</button>
                </form>
            `;
            document.getElementById('prescriptionDetails').innerHTML = html;
            showModal('prescriptionModal');
        });
}
</script>

</main>
</body>
</html>
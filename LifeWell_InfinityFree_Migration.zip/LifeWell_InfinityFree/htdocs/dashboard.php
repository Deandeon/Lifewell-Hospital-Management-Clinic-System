<?php
require_once 'config.php';
requireLogin();

switch ($_SESSION['role']) {
    case 'nurse':
        header('Location: nurse_dashboard.php');
        break;
    case 'doctor':
        header('Location: doctor_dashboard.php');
        break;
    case 'pharmacist':
        header('Location: pharmacist_dashboard.php');
        break;
    case 'diagnostic':
        header('Location: diagnostic_dashboard.php');
        break;
    case 'admin':
        header('Location: admin_dashboard.php');
        break;
    default:
        session_destroy();
        header('Location: login.php');
}
exit();
?>
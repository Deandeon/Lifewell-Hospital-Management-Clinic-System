<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LifeWell Hospital Management System</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            overflow-x: hidden;
            color: #2d3748;
        }

        /* Animated Background */
        .bg-container {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: -1;
            overflow: hidden;
        }

        .bg-image {
            position: absolute;
            top: 0;
            left: 0;
            width: 120%;
            height: 100%;
            background: url('imgs/hospic.jpg') center/cover no-repeat;
            animation: slideBackground 30s linear infinite;
            filter: brightness(0.4);
        }

        /* If you don't have an image, use this gradient fallback */
        .bg-fallback {
            position: absolute;
            top: 0;
            left: 0;
            width: 120%;
            height: 100%;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 50%, #f093fb 100%);
            animation: slideBackground 30s linear infinite;
            opacity: 0.8;
        }

        @keyframes slideBackground {
            0% {
                transform: translateX(0);
            }
            100% {
                transform: translateX(-20%);
            }
        }

        /* Overlay */
        .overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 0;
        }

        /* Content Container */
        .container {
            position: relative;
            z-index: 1;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
            justify-content: center;
            align-items: center;
            padding: 40px 20px;
            text-align: center;
        }

        /* Logo/Header */
        .logo {
            font-size: 4em;
            font-weight: bold;
            color: white;
            margin-bottom: 20px;
            text-shadow: 0 4px 20px rgba(0, 0, 0, 0.5);
            animation: fadeInDown 1s ease-out;
        }

        .logo-subtitle {
            font-size: 1.5em;
            color: #e2e8f0;
            margin-bottom: 50px;
            text-shadow: 0 2px 10px rgba(0, 0, 0, 0.5);
            animation: fadeInDown 1s ease-out 0.2s both;
        }

        /* Main Content Card */
        .content-card {
            background: rgba(255, 255, 255, 0.95);
            backdrop-filter: blur(10px);
            padding: 50px 40px;
            border-radius: 20px;
            max-width: 800px;
            box-shadow: 0 20px 60px rgba(0, 0, 0, 0.3);
            animation: fadeInUp 1s ease-out 0.4s both;
        }

        .content-card h2 {
            color: #2a5298;
            font-size: 2.5em;
            margin-bottom: 25px;
        }

        .content-card p {
            color: #4a5568;
            font-size: 1.2em;
            line-height: 1.8;
            margin-bottom: 30px;
        }

        /* Users Section */
        .users-section {
            margin: 40px 0;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
        }

        .user-card {
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 25px 15px;
            border-radius: 12px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .user-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 30px rgba(102, 126, 234, 0.4);
        }

        .user-icon {
            font-size: 2.5em;
            margin-bottom: 10px;
        }

        .user-title {
            font-weight: bold;
            font-size: 1.1em;
            margin-bottom: 5px;
        }

        .user-desc {
            font-size: 0.9em;
            opacity: 0.9;
        }

        /* CTA Button */
        .cta-button {
            display: inline-block;
            margin-top: 30px;
            padding: 20px 50px;
            font-size: 1.5em;
            font-weight: bold;
            color: white;
            background: linear-gradient(135deg, #2a5298 0%, #1e3c72 100%);
            border: none;
            border-radius: 50px;
            text-decoration: none;
            cursor: pointer;
            transition: all 0.3s ease;
            box-shadow: 0 10px 30px rgba(42, 82, 152, 0.4);
            animation: pulse 2s ease-in-out infinite;
        }

        .cta-button:hover {
            transform: translateY(-3px) scale(1.05);
            box-shadow: 0 15px 40px rgba(42, 82, 152, 0.6);
            animation: none;
        }

        /* Animations */
        @keyframes fadeInDown {
            from {
                opacity: 0;
                transform: translateY(-30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes fadeInUp {
            from {
                opacity: 0;
                transform: translateY(30px);
            }
            to {
                opacity: 1;
                transform: translateY(0);
            }
        }

        @keyframes pulse {
            0%, 100% {
                box-shadow: 0 10px 30px rgba(42, 82, 152, 0.4);
            }
            50% {
                box-shadow: 0 10px 40px rgba(42, 82, 152, 0.7);
            }
        }

        /* Features List */
        .features {
            text-align: left;
            margin: 30px 0;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
        }

        .feature-item {
            display: flex;
            align-items: start;
            gap: 15px;
        }

        .feature-icon {
            font-size: 2em;
            color: #2a5298;
        }

        .feature-text h3 {
            color: #2a5298;
            margin-bottom: 5px;
            font-size: 1.1em;
        }

        .feature-text p {
            color: #718096;
            font-size: 0.95em;
            margin: 0;
        }

        /* Responsive */
        @media (max-width: 768px) {
            .logo {
                font-size: 2.5em;
            }

            .logo-subtitle {
                font-size: 1.2em;
            }

            .content-card {
                padding: 30px 20px;
            }

            .content-card h2 {
                font-size: 2em;
            }

            .content-card p {
                font-size: 1em;
            }

            .cta-button {
                padding: 15px 35px;
                font-size: 1.2em;
            }

            .users-section {
                grid-template-columns: 1fr 1fr;
            }

            .features {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
    <!-- Background (Replace 'hospital-bg.jpg' with your actual image) -->
    <div class="bg-container">
        
        <div class="bg-image" style="background-image: url('imgs/hospic.jpg');"></div>
        
        <!-- Use this fallback if you don't have an image -->
        <!-- <div class="bg-fallback"></div> -->
    </div>
    
    <!-- Overlay -->
    <div class="overlay"></div>

    <!-- Main Content -->
    <div class="container">
        <div class="logo">LifeWell</div>
        <div class="logo-subtitle">Hospital Management System</div>

        <div class="content-card">
            <h2> Revolutionizing Healthcare Management</h2>
            
            <p>
                LifeWell is a comprehensive hospital management system designed to streamline 
                patient care through efficient workflow management and real-time communication 
                between medical staff. From patient registration to prescription dispensing, 
                we've got every step covered.
            </p>

            <div class="features">
                <div class="feature-item">
                    <div class="feature-icon">
        <img src="imgs/admin.ico" style="width:40px; height:40px;">
    
                    </div>
                    <div class="feature-text">
                        <h3>Real-Time Workflow</h3>
                        <p>Seamless patient handoffs between departments</p>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                         <img src="imgs/computer.png" style="width:40px; height:40px;">
                    </div>
                    <div class="feature-text">
                        <h3>Smart Tracking</h3>
                        <p>Monitor patient journey from intake to discharge</p>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">
                         <img src="imgs/key.ico" style="width:40px; height:40px;">
                    </div>
                    <div class="feature-text">
                        <h3>Secure & Reliable</h3>
                        <p>Role-based access control for data protection</p>
                    </div>
                </div>
                <div class="feature-item">
                    <div class="feature-icon">💡</div>
                    <div class="feature-text">
                        <h3>User-Friendly</h3>
                        <p>Intuitive interface for all staff members</p>
                    </div>
                </div>
            </div>


            <img src="imgs/redcross.ico" style="width:40px; height:40px;">
            <h2 style="margin-top: 40px; font-size: 2em;"> Who Uses LifeWell?</h2>
            
            <div class="users-section">
                <div class="user-card">
                    <div class="user-icon">
                         <img src="imgs/user.png" style="width:40px; height:40px;">
                    </div>
                    <div class="user-title">Doctors</div>
                    <div class="user-desc">Diagnose, prescribe, and request diagnostics</div>
                </div>

                <div class="user-card">
                    <div class="user-icon">
                        <img src="imgs/nurse.ico" style="width:40px; height:40px;">
                    </div>
                    <div class="user-title">Nurses</div>
                    <div class="user-desc">Register patients and record vitals</div>
                </div>

                <div class="user-card">
                    <div class="user-icon">
                        <img src="imgs/pharma.png" style="width:40px; height:40px;">
                    </div>
                    <div class="user-title">Pharmacists</div>
                    <div class="user-desc">Dispense medications and manage prescriptions</div>
                </div>

                <div class="user-card">
                    <div class="user-icon">
                        <img src="imgs/diag.ico" style="width:40px; height:40px;">
                    
                    </div>
                    <div class="user-title">Diagnostic Staff</div>
                    <div class="user-desc">Perform tests and upload results</div>
                </div>

                <div class="user-card">
                    <div class="user-icon">
                        <img src="imgs/admin.ico" style="width:40px; height:40px;">

                    </div>
                    <div class="user-title">Administrators</div>
                    <div class="user-desc">Manage users and monitor system activity</div>
                </div>
            </div>

            <a href="login.php" class="cta-button">
                    <div class="user-icon">
                        <img src="imgs/bullet.ico" style="width:40px; height:40px;">
                  Let's See The Experience
                </div>
            </a>

            <p style="margin-top: 30px; font-size: 0.9em; color: #a0aec0;">
                Made by David Orhin &copy; 2025 lifeWell Hospital Management System
            </p>
        </div>
    </div>

    <script>
        
        document.querySelector('.cta-button').addEventListener('click', function(e) {
        
        });

        window.addEventListener('load', function() {
            document.body.style.opacity = '0';
            setTimeout(function() {
                document.body.style.transition = 'opacity 0.5s ease-in';
                document.body.style.opacity = '1';
            }, 100);
        });
    </script>
</body>
</html>
<?php
require_once 'config.php';
requireLogin();

$page_title = 'Patient Information Lookup';

// Search functionality
$search = isset($_GET['search']) ? sanitize($_GET['search']) : '';
$where_clause = '';
if ($search) {
    $where_clause = "WHERE p.patient_code LIKE '%$search%' 
                     OR p.first_name LIKE '%$search%' 
                     OR p.last_name LIKE '%$search%' 
                     OR p.phone_number LIKE '%$search%'";
}


$patients = $conn->query("
    SELECT p.*, 
           COUNT(DISTINCT v.visit_id) as total_visits,
           MAX(v.visit_date) as last_visit,
           TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) as age
    FROM lw_patients p
    LEFT JOIN lw_patient_visits v ON p.patient_id = v.patient_id
    $where_clause
    GROUP BY p.patient_id
    ORDER BY p.created_at DESC
");

include 'includes/header.php';
?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">🔍 Patient Information Lookup</h2>
        <form method="GET" style="display: flex; gap: 10px; flex: 1; max-width: 500px;">
            <input type="text" name="search" placeholder="Search by name, code, or phone..." 
                   value="<?php echo htmlspecialchars($search); ?>" 
                   style="flex: 1; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px;">
            <button type="submit" class="btn btn-primary">Search</button>
            <?php if ($search): ?>
                <a href="patient_lookup.php" class="btn btn-secondary">Clear</a>
            <?php endif; ?>
        </form>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Patient Code</th>
                    <th>Name</th>
                    <th>Age / Gender</th>
                    <th>Contact</th>
                    <th>Blood Group</th>
                    <th>Total Visits</th>
                    <th>Last Visit</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($patients->num_rows === 0): ?>
                    <tr><td colspan="8" style="text-align: center; padding: 20px; color: var(--text-tertiary);">
                        <?php echo $search ? 'No patients found matching your search' : 'No patients registered yet'; ?>
                    </td></tr>
                <?php endif; ?>
                <?php while ($patient = $patients->fetch_assoc()): ?>
                <tr>
                    <td><strong><?php echo htmlspecialchars($patient['patient_code']); ?></strong></td>
                    <td><?php echo htmlspecialchars($patient['first_name'] . ' ' . $patient['last_name']); ?></td>
                    <td><?php echo $patient['age']; ?>Y / <?php echo $patient['gender']; ?></td>
                    <td>
                        <?php echo htmlspecialchars($patient['phone_number']); ?><br>
                        <small><?php echo htmlspecialchars($patient['email'] ?: 'No email'); ?></small>
                    </td>
                    <td><?php echo $patient['blood_group'] ?: 'N/A'; ?></td>
                    <td><span class="badge badge-info"><?php echo $patient['total_visits']; ?></span></td>
                    <td><?php echo $patient['last_visit'] ? date('M d, Y', strtotime($patient['last_visit'])) : 'Never'; ?></td>
                    <td>
                        <button onclick="viewPatientDetails(<?php echo $patient['patient_id']; ?>)" class="btn btn-primary">View Details</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Patient Details  -->
<div id="patientDetailsModal" class="modal">
    <div class="modal-content" style="max-width: 1000px;">
        <div class="modal-header">
            <h2>Patient Details</h2>
            <button class="modal-close" onclick="closeModal('patientDetailsModal')">&times;</button>
        </div>
        <div id="patientDetailsContent"></div>
    </div>
</div>

<script>
function viewPatientDetails(patientId) {
    fetch('get_patient_full_details.php?patient_id=' + patientId)
        .then(res => res.json())
        .then(data => {
            displayPatientDetails(data);
            showModal('patientDetailsModal');
        })
        .catch(error => {
            alert('Error loading patient details');
            console.error(error);
        });
}

function displayPatientDetails(data) {
    const patient = data.patient;
    const visits = data.visits;
    
    let visitsHtml = '';
    if (visits.length === 0) {
        visitsHtml = '<p style="text-align: center; color: var(--text-tertiary); padding: 20px;">No visits recorded</p>';
    } else {
        visitsHtml = `
            <table style="width: 100%; margin-top: 15px;">
                <thead>
                    <tr>
                        <th>Date</th>
                        <th>Chief Complaint</th>
                        <th>Status</th>
                        <th>Priority</th>
                    </tr>
                </thead>
                <tbody>
                    ${visits.map(visit => `
                        <tr>
                            <td>${visit.visit_date}</td>
                            <td>${visit.chief_complaint}</td>
                            <td><span class="badge badge-info">${visit.visit_status}</span></td>
                            <td><span class="badge badge-${visit.priority === 'emergency' ? 'danger' : (visit.priority === 'urgent' ? 'warning' : 'info')}">${visit.priority}</span></td>
                        </tr>
                    `).join('')}
                </tbody>
            </table>
        `;
    }
    
    const html = `
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px;">
            <div class="card">
                <h3>Personal Information</h3>
                <p><strong>Patient Code:</strong> ${patient.patient_code}</p>
                <p><strong>Full Name:</strong> ${patient.first_name} ${patient.last_name}</p>
                <p><strong>Date of Birth:</strong> ${patient.date_of_birth} (Age: ${patient.age})</p>
                <p><strong>Gender:</strong> ${patient.gender}</p>
                <p><strong>Blood Group:</strong> ${patient.blood_group || 'Not specified'}</p>
            </div>
            
            <div class="card">
                <h3>Contact Information</h3>
                <p><strong>Phone:</strong> ${patient.phone_number}</p>
                <p><strong>Email:</strong> ${patient.email || 'Not provided'}</p>
                <p><strong>Address:</strong> ${patient.address || 'Not provided'}</p>
                <p><strong>Emergency Contact:</strong> ${patient.emergency_contact_name || 'Not provided'}</p>
                <p><strong>Emergency Phone:</strong> ${patient.emergency_contact_phone || 'Not provided'}</p>
            </div>
        </div>
        
        <div class="card" style="margin-top: 20px;">
            <h3>Medical Information</h3>
            <p><strong>Allergies:</strong> ${patient.allergies || 'None recorded'}</p>
            <p><strong>Medical History:</strong> ${patient.medical_history || 'None recorded'}</p>
        </div>
        
        <div class="card" style="margin-top: 20px;">
            <h3>Visit History (${visits.length} total visits)</h3>
            ${visitsHtml}
        </div>
    `;
    
    document.getElementById('patientDetailsContent').innerHTML = html;
}
</script>

</main>
</body>
</html>
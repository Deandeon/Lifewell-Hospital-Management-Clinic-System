<?php
if (!isset($_SESSION)) {
    session_start();
}

$theme = isset($_SESSION['theme']) ? $_SESSION['theme'] : 'light';
$page_title = isset($page_title) ? $page_title : 'Dashboard';
?>
<!DOCTYPE html>
<html lang="en" data-theme="<?php echo $theme; ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($page_title); ?> - LifeWell Hospital</title>
    <style>
        :root[data-theme="light"] {
            --bg-primary: #f5f7fa;
            --bg-secondary: #ffffff;
            --bg-tertiary: #e3e8ef;
            --text-primary: #2d3748;
            --text-secondary: #4a5568;
            --text-tertiary: #718096;
            --accent-primary: #2a5298;
            --accent-secondary: #1e3c72;
            --accent-hover: #3d6bb3;
            --border-color: #e2e8f0;
            --shadow: rgba(0, 0, 0, 0.1);
            --success: #48bb78;
            --warning: #ed8936;
            --danger: #f56565;
            --info: #4299e1;
        }
        
        :root[data-theme="dark"] {
            --bg-primary: #1a202c;
            --bg-secondary: #2d3748;
            --bg-tertiary: #4a5568;
            --text-primary: #f7fafc;
            --text-secondary: #e2e8f0;
            --text-tertiary: #cbd5e0;
            --accent-primary: #4299e1;
            --accent-secondary: #3182ce;
            --accent-hover: #63b3ed;
            --border-color: #4a5568;
            --shadow: rgba(0, 0, 0, 0.3);
            --success: #48bb78;
            --warning: #ed8936;
            --danger: #f56565;
            --info: #4299e1;
        }
        
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--bg-primary);
            color: var(--text-primary);
            transition: background-color 0.3s, color 0.3s;
        }
        
        .header {
            background: var(--bg-secondary);
            box-shadow: 0 2px 10px var(--shadow);
            position: sticky;
            top: 0;
            z-index: 1000;
            border-bottom: 3px solid var(--accent-primary);
        }
        
        .header-content {
            max-width: 1400px;
            margin: 0 auto;
            padding: 15px 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
            gap: 20px;
        }
        
        .logo {
            font-size: 1.8em;
            font-weight: bold;
            background: linear-gradient(135deg, var(--accent-primary), var(--accent-secondary));
            -webkit-background-clip: text;
            -webkit-text-fill-color: transparent;
            background-clip: text;
            cursor: pointer;
        }
        
        .nav-links {
            display: flex;
            gap: 15px;
            flex: 1;
            justify-content: center;
            flex-wrap: wrap;
        }
        
        .nav-links a {
            color: var(--text-primary);
            text-decoration: none;
            padding: 8px 16px;
            border-radius: 6px;
            transition: all 0.3s;
            font-weight: 500;
        }
        
        .nav-links a:hover {
            background: var(--bg-tertiary);
            color: var(--accent-primary);
        }
        
        .header-right {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .user-info {
            display: flex;
            align-items: center;
            gap: 15px;
        }
        
        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: var(--accent-primary);
            color: white;
            display: flex;
            align-items: center;
            justify-content: center;
            font-weight: bold;
        }
        
        .user-details {
            display: flex;
            flex-direction: column;
        }
        
        .user-name {
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .user-role {
            font-size: 0.85em;
            color: var(--text-tertiary);
            text-transform: capitalize;
        }
        
        .theme-toggle {
            width: 50px;
            height: 26px;
            background: var(--border-color);
            border-radius: 13px;
            position: relative;
            cursor: pointer;
            transition: background 0.3s;
        }
        
        .theme-toggle::after {
            content: '';
            position: absolute;
            width: 22px;
            height: 22px;
            border-radius: 50%;
            background: white;
            top: 2px;
            left: 2px;
            transition: transform 0.3s;
            box-shadow: 0 2px 4px rgba(0,0,0,0.2);
        }
        
        [data-theme="dark"] .theme-toggle {
            background: var(--accent-primary);
        }
        
        [data-theme="dark"] .theme-toggle::after {
            transform: translateX(24px);
        }
        
        .btn {
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 1em;
            transition: all 0.3s;
            text-decoration: none;
            display: inline-block;
        }
        
        .btn-primary {
            background: var(--accent-primary);
            color: white;
        }
        
        .btn-primary:hover {
            background: var(--accent-hover);
            transform: translateY(-2px);
            box-shadow: 0 4px 12px var(--shadow);
        }
        
        .btn-secondary {
            background: var(--bg-tertiary);
            color: var(--text-primary);
        }
        
        .btn-secondary:hover {
            background: var(--border-color);
        }
        
        .btn-danger {
            background: var(--danger);
            color: white;
        }
        
        .btn-danger:hover {
            opacity: 0.9;
        }
        
        .main-content {
            max-width: 1400px;
            margin: 30px auto;
            padding: 0 30px;
        }
        
        .card {
            background: var(--bg-secondary);
            border-radius: 12px;
            padding: 25px;
            box-shadow: 0 2px 10px var(--shadow);
            margin-bottom: 20px;
        }
        
        .card-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid var(--border-color);
        }
        
        .card-title {
            font-size: 1.5em;
            font-weight: 600;
            color: var(--text-primary);
        }
        
        .table-container {
            overflow-x: auto;
        }
        
        table {
            width: 100%;
            border-collapse: collapse;
        }
        
        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid var(--border-color);
        }
        
        th {
            background: var(--bg-tertiary);
            font-weight: 600;
            color: var(--text-primary);
        }
        
        tr:hover {
            background: var(--bg-tertiary);
        }
        
        .badge {
            padding: 6px 12px;
            border-radius: 20px;
            font-size: 0.85em;
            font-weight: 600;
            display: inline-block;
        }
        
        .badge-success {
            background: #c6f6d5;
            color: #22543d;
        }
        
        .badge-warning {
            background: #feebc8;
            color: #7c2d12;
        }
        
        .badge-danger {
            background: #fed7d7;
            color: #742a2a;
        }
        
        .badge-info {
            background: #bee3f8;
            color: #2c5282;
        }
        
        [data-theme="dark"] .badge-success {
            background: #22543d;
            color: #c6f6d5;
        }
        
        [data-theme="dark"] .badge-warning {
            background: #7c2d12;
            color: #feebc8;
        }
        
        [data-theme="dark"] .badge-danger {
            background: #742a2a;
            color: #fed7d7;
        }
        
        [data-theme="dark"] .badge-info {
            background: #2c5282;
            color: #bee3f8;
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
            color: var(--text-secondary);
        }
        
        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px;
            border: 2px solid var(--border-color);
            border-radius: 8px;
            background: var(--bg-primary);
            color: var(--text-primary);
            font-size: 1em;
            transition: all 0.3s;
        }
        
        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: var(--accent-primary);
            box-shadow: 0 0 0 3px rgba(42, 82, 152, 0.1);
        }
        
        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }
        
        .stat-card {
            background: var(--bg-secondary);
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 2px 10px var(--shadow);
            border-left: 4px solid var(--accent-primary);
        }
        
        .stat-label {
            color: var(--text-tertiary);
            font-size: 0.9em;
            margin-bottom: 8px;
        }
        
        .stat-value {
            font-size: 2.5em;
            font-weight: bold;
            color: var(--accent-primary);
        }
        
        .alert {
            padding: 15px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        
        .alert-success {
            background: #c6f6d5;
            color: #22543d;
            border-left: 4px solid #48bb78;
        }
        
        .alert-danger {
            background: #fed7d7;
            color: #742a2a;
            border-left: 4px solid #f56565;
        }
        
        .alert-info {
            background: #bee3f8;
            color: #2c5282;
            border-left: 4px solid #4299e1;
        }
        
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.6);
            z-index: 2000;
            justify-content: center;
            align-items: center;
        }
        
        .modal.active {
            display: flex;
        }
        
        .modal-content {
            background: var(--bg-secondary);
            border-radius: 12px;
            padding: 30px;
            max-width: 600px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }
        
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }
        
        .modal-close {
            background: none;
            border: none;
            font-size: 1.5em;
            cursor: pointer;
            color: var(--text-tertiary);
        }
        
        @media (max-width: 768px) {
            .header-content {
                flex-direction: column;
                gap: 15px;
            }
            
            .nav-links {
                width: 100%;
                justify-content: flex-start;
            }
            
            .stats-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
    <script>
        function toggleTheme() {
            const html = document.documentElement;
            const currentTheme = html.getAttribute('data-theme');
            const newTheme = currentTheme === 'light' ? 'dark' : 'light';
            html.setAttribute('data-theme', newTheme);
            
            fetch('update_theme.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: 'theme=' + newTheme
            });
        }
        
        function showModal(modalId) {
            document.getElementById(modalId).classList.add('active');
        }
        
        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('active');
        }
        
        window.onclick = function(event) {
            if (event.target.classList.contains('modal')) {
                event.target.classList.remove('active');
            }
        }
        
        function goToDashboard() {
            window.location.href = 'dashboard.php';
        }
    </script>
</head>
<body>
    <header class="header">
        <div class="header-content">
            <div class="logo" onclick="goToDashboard()">
             <img src="imgs/lf.png" style="width:40px; height:40px;">      
            LifeWell</div>
            
            <nav class="nav-links">
                <?php if (hasRole('admin')): ?>
                    <a href="admin_dashboard.php">Dashboard</a>
                    <a href="user_management.php">
                 <img src="imgs/user.png" style="width:20px; height:20px;">    
                    Users</a>
                    <a href="patient_lookup.php">🔍 Patients</a>
                    <a href="activity_log.php">📋 Activity Log</a>
                <?php elseif (hasRole('nurse')): ?>
                    <a href="nurse_dashboard.php">Dashboard</a>
                    <a href="patient_lookup.php">🔍 Patients</a>
                <?php elseif (hasRole('doctor')): ?>
                    <a href="doctor_dashboard.php">Dashboard</a>
                    <a href="patient_lookup.php">🔍 Patients</a>
                <?php elseif (hasRole('pharmacist')): ?>
                    <a href="pharmacist_dashboard.php">Dashboard</a>
                    <a href="patient_lookup.php">🔍 Patients</a>
                <?php elseif (hasRole('diagnostic')): ?>
                    <a href="diagnostic_dashboard.php">Dashboard</a>
                    <a href="patient_lookup.php">🔍 Patients</a>
                <?php endif; ?>
            </nav>
            
            <div class="header-right">
                <div class="theme-toggle" onclick="toggleTheme()" title="Toggle Theme"></div>
                <div class="user-info">
                    <div class="user-avatar"><?php echo strtoupper(substr($_SESSION['full_name'], 0, 1)); ?></div>
                    <div class="user-details">
                        <div class="user-name"><?php echo htmlspecialchars($_SESSION['full_name']); ?></div>
                        <div class="user-role"><?php echo htmlspecialchars($_SESSION['role']); ?></div>
                    </div>
                </div>
                <a href="settings.php" class="btn btn-secondary">Settings</a>
                <a href="logout.php" class="btn btn-danger">Logout</a>
            </div>
        </div>
    </header>
    <main class="main-content">
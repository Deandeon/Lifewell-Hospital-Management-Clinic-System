<?php
require_once 'config.php';
requireLogin();

if (!isset($_GET['prescription_id'])) {
    die(json_encode(['error' => 'Prescription ID required']));
}

$prescription_id = intval($_GET['prescription_id']);

//  info
$prescription = $conn->query("
    SELECT pr.*, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
           doc.full_name as doctor_name
    FROM lw_prescriptions pr
    JOIN lw_patient_visits v ON pr.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    JOIN lw_users doc ON pr.doctor_id = doc.user_id
    WHERE pr.prescription_id = $prescription_id
")->fetch_assoc();

// items
$items_query = $conn->query("SELECT * FROM lw_prescription_items WHERE prescription_id = $prescription_id");
$items = [];
while ($item = $items_query->fetch_assoc()) {
    $items[] = $item;
}

$response = [
    'patient_name' => $prescription['patient_name'],
    'doctor_name' => $prescription['doctor_name'],
    'prescription_date' => date('M d, Y h:i A', strtotime($prescription['prescription_date'])),
    'notes' => $prescription['notes'],
    'items' => $items
];

header('Content-Type: application/json');
echo json_encode($response);
?>


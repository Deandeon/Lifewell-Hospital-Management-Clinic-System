<?php
require_once 'config.php';
requireLogin();

if (!hasRole('diagnostic')) {
    header('Location: dashboard.php');
    exit();
}

$page_title = 'Diagnostic Dashboard';
$success = '';
$error = '';

// Handle starting diagnostic work
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'start_work') {
    $request_id = intval($_POST['request_id']);
    $conn->query("UPDATE lw_diagnostic_requests SET status = 'in_progress' WHERE request_id = $request_id");
    $success = "Test marked as in progress";
}

// Handle submitting results with files
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_results') {
    $request_id = intval($_POST['request_id']);
    $result_summary = sanitize($_POST['result_summary']);
    $findings = sanitize($_POST['findings']);
    $recommendations = sanitize($_POST['recommendations']);
    
    // Create result entry
    $stmt = $conn->prepare("INSERT INTO lw_diagnostic_results (request_id, performed_by, result_summary, findings, recommendations) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $request_id, $_SESSION['user_id'], $result_summary, $findings, $recommendations);
    
    if ($stmt->execute()) {
        $result_id = $stmt->insert_id;
        
        // Handle file uploads
        if (isset($_FILES['diagnostic_files'])) {
            $files = $_FILES['diagnostic_files'];
            $file_count = count($files['name']);
            
            for ($i = 0; $i < $file_count; $i++) {
                if ($files['error'][$i] === UPLOAD_ERR_OK) {
                    $file = [
                        'name' => $files['name'][$i],
                        'type' => $files['type'][$i],
                        'tmp_name' => $files['tmp_name'][$i],
                        'error' => $files['error'][$i],
                        'size' => $files['size'][$i]
                    ];
                    
                    $upload_result = uploadDiagnosticFile($file, $result_id, $_SESSION['user_id']);
                    if (!$upload_result['success']) {
                        $error = implode(', ', $upload_result['errors']);
                    }
                }
            }
        }
        
        // Mark request as completed
        $conn->query("UPDATE lw_diagnostic_requests SET status = 'completed', completion_date = NOW() WHERE request_id = $request_id");
        
        // Get request details to notify doctor
        $request_details = $conn->query("SELECT dr.visit_id, dr.requested_by, v.visit_status FROM lw_diagnostic_requests dr JOIN lw_patient_visits v ON dr.visit_id = v.visit_id WHERE dr.request_id = $request_id")->fetch_assoc();
        
        // Check if all tests for this consultation are complete
        $consultation_id = $conn->query("SELECT consultation_id FROM lw_diagnostic_requests WHERE request_id = $request_id")->fetch_assoc()['consultation_id'];
        $pending_tests = $conn->query("SELECT COUNT(*) as count FROM lw_diagnostic_requests WHERE consultation_id = $consultation_id AND status != 'completed'")->fetch_assoc()['count'];
        
        if ($pending_tests == 0) {
            // All tests complete, send back to doctor
            $visit_id = $request_details['visit_id'];
            $doctor_id = $request_details['requested_by'];
            $conn->query("UPDATE lw_patient_visits SET visit_status = 'with_doctor', current_handler_id = $doctor_id WHERE visit_id = $visit_id");
            
            $patient_info = $conn->query("SELECT CONCAT(p.first_name, ' ', p.last_name) as name FROM lw_patients p JOIN lw_patient_visits v ON p.patient_id = v.patient_id WHERE v.visit_id = $visit_id")->fetch_assoc();
            createNotification($conn, $doctor_id, $visit_id, 'Diagnostic Results Ready', 'All diagnostic tests completed for patient: ' . $patient_info['name'], 'success');
            
            logActivity($conn, $visit_id, $_SESSION['user_id'], 'diagnostic_completed', 'All diagnostic tests completed and sent back to doctor', 'with_diagnostic', 'with_doctor');
        }
        
        $success = "Results submitted successfully!";
    } else {
        $error = "Failed to submit results";
    }
}

// Get pending requests
$pending_requests = $conn->query("
    SELECT dr.*, v.visit_id, p.patient_code, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
           doc.full_name as doctor_name, c.diagnosis
    FROM lw_diagnostic_requests dr
    JOIN lw_patient_visits v ON dr.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    JOIN lw_users doc ON dr.requested_by = doc.user_id
    LEFT JOIN lw_consultations c ON dr.consultation_id = c.consultation_id
    WHERE dr.assigned_to = {$_SESSION['user_id']} AND dr.status IN ('pending', 'in_progress')
    ORDER BY dr.urgency DESC, dr.request_date ASC
");

// Get completed requests
$completed_requests = $conn->query("
    SELECT dr.*, v.visit_id, p.patient_code, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
           dres.result_summary, dres.result_date
    FROM lw_diagnostic_requests dr
    JOIN lw_patient_visits v ON dr.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    LEFT JOIN lw_diagnostic_results dres ON dr.request_id = dres.request_id
    WHERE dr.assigned_to = {$_SESSION['user_id']} AND dr.status = 'completed'
    ORDER BY dr.completion_date DESC
    LIMIT 20
");

// Get stats
$stats = [
    'pending' => $conn->query("SELECT COUNT(*) as count FROM lw_diagnostic_requests WHERE assigned_to = {$_SESSION['user_id']} AND status = 'pending'")->fetch_assoc()['count'],
    'in_progress' => $conn->query("SELECT COUNT(*) as count FROM lw_diagnostic_requests WHERE assigned_to = {$_SESSION['user_id']} AND status = 'in_progress'")->fetch_assoc()['count'],
    'completed_today' => $conn->query("SELECT COUNT(*) as count FROM lw_diagnostic_requests WHERE assigned_to = {$_SESSION['user_id']} AND status = 'completed' AND DATE(completion_date) = CURDATE()")->fetch_assoc()['count']
];

include 'includes/header.php';
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-label">Pending Requests</div>
        <div class="stat-value"><?php echo $stats['pending']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">In Progress</div>
        <div class="stat-value"><?php echo $stats['in_progress']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Completed Today</div>
        <div class="stat-value"><?php echo $stats['completed_today']; ?></div>
    </div>
</div>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Pending & In Progress Tests</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Patient</th>
                    <th>Test Type</th>
                    <th>Description</th>
                    <th>Requested By</th>
                    <th>Urgency</th>
                    <th>Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($request = $pending_requests->fetch_assoc()): ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($request['patient_name']); ?></strong><br>
                        <small><?php echo htmlspecialchars($request['patient_code']); ?></small>
                    </td>
                    <td><?php echo ucfirst(str_replace('_', ' ', $request['test_type'])); ?></td>
                    <td><?php echo htmlspecialchars($request['test_description']); ?></td>
                    <td><?php echo htmlspecialchars($request['doctor_name']); ?></td>
                    <td><span class="badge badge-<?php echo $request['urgency'] === 'stat' ? 'danger' : ($request['urgency'] === 'urgent' ? 'warning' : 'info'); ?>"><?php echo ucfirst($request['urgency']); ?></span></td>
                    <td><span class="badge badge-<?php echo $request['status'] === 'in_progress' ? 'warning' : 'info'; ?>"><?php echo ucfirst($request['status']); ?></span></td>
                    <td>
                        <?php if ($request['status'] === 'pending'): ?>
                            <form method="POST" style="display: inline;">
                                <input type="hidden" name="action" value="start_work">
                                <input type="hidden" name="request_id" value="<?php echo $request['request_id']; ?>">
                                <button type="submit" class="btn btn-primary">Start</button>
                            </form>
                        <?php else: ?>
                            <button onclick="submitResults(<?php echo $request['request_id']; ?>, '<?php echo htmlspecialchars($request['patient_name']); ?>', '<?php echo htmlspecialchars($request['test_type']); ?>')" class="btn btn-primary">Submit Results</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Recently Completed</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Patient</th>
                    <th>Test Type</th>
                    <th>Result Summary</th>
                    <th>Completed</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($request = $completed_requests->fetch_assoc()): ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($request['patient_name']); ?></strong><br>
                        <small><?php echo htmlspecialchars($request['patient_code']); ?></small>
                    </td>
                    <td><?php echo ucfirst(str_replace('_', ' ', $request['test_type'])); ?></td>
                    <td><?php echo htmlspecialchars($request['result_summary']); ?></td>
                    <td><?php echo date('M d, Y h:i A', strtotime($request['result_date'])); ?></td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Submit Results Modal -->
<div id="resultsModal" class="modal">
    <div class="modal-content" style="max-width: 800px;">
        <div class="modal-header">
            <h2>Submit Diagnostic Results</h2>
            <button class="modal-close" onclick="closeModal('resultsModal')">&times;</button>
        </div>
        <div id="resultsFormContainer"></div>
    </div>
</div>

<script>
function submitResults(requestId, patientName, testType) {
    const html = `
        <div style="background: var(--bg-tertiary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
            <p><strong>Patient:</strong> ${patientName}</p>
            <p><strong>Test Type:</strong> ${testType}</p>
        </div>
        <form method="POST" enctype="multipart/form-data">
            <input type="hidden" name="action" value="submit_results">
            <input type="hidden" name="request_id" value="${requestId}">
            
            <div class="form-group">
                <label>Result Summary *</label>
                <textarea name="result_summary" rows="3" required placeholder="Brief summary of test results..."></textarea>
            </div>
            
            <div class="form-group">
                <label>Detailed Findings *</label>
                <textarea name="findings" rows="5" required placeholder="Detailed findings and observations..."></textarea>
            </div>
            
            <div class="form-group">
                <label>Recommendations</label>
                <textarea name="recommendations" rows="3" placeholder="Clinical recommendations based on results..."></textarea>
            </div>
            
            <div class="form-group">
                <label>Upload Files (X-rays, Lab Reports, Scans, etc.)</label>
                <input type="file" name="diagnostic_files[]" multiple accept=".pdf,.jpg,.jpeg,.png,.dcm,.doc,.docx">
                <small style="color: var(--text-tertiary); display: block; margin-top: 8px;">
                    Allowed formats: PDF, JPG, PNG, DICOM (.dcm), DOC, DOCX (Max 10MB per file)
                </small>
            </div>
            
            <div style="background: #fef3c7; color: #78350f; padding: 12px; border-radius: 8px; margin: 15px 0;">
                <strong>Note:</strong> You can upload multiple files at once. Hold Ctrl/Cmd to select multiple files.
            </div>
            
            <button type="submit" class="btn btn-primary">Submit Results & Forward to Doctor</button>
        </form>
    `;
    document.getElementById('resultsFormContainer').innerHTML = html;
    showModal('resultsModal');
}
</script>

</main>
</body>
</html>
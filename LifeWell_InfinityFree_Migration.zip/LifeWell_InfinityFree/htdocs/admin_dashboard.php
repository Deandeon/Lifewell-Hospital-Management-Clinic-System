<?php
require_once 'config.php';
requireLogin();

if (!hasRole('admin')) {
    header('Location: dashboard.php');
    exit();
}

$page_title = 'Admin Dashboard';


$stats = [
    'total_users' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE is_active = TRUE")->fetch_assoc()['count'],
    'total_patients' => $conn->query("SELECT COUNT(*) as count FROM lw_patients")->fetch_assoc()['count'],
    'active_visits' => $conn->query("SELECT COUNT(*) as count FROM lw_patient_visits WHERE visit_status != 'completed'")->fetch_assoc()['count'],
    'completed_today' => $conn->query("SELECT COUNT(*) as count FROM lw_patient_visits WHERE visit_status = 'completed' AND DATE(visit_date) = CURDATE()")->fetch_assoc()['count'],
    'nurses' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'nurse' AND is_active = TRUE")->fetch_assoc()['count'],
    'doctors' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'doctor' AND is_active = TRUE")->fetch_assoc()['count'],
    'pharmacists' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'pharmacist' AND is_active = TRUE")->fetch_assoc()['count'],
    'diagnostic_staff' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'diagnostic' AND is_active = TRUE")->fetch_assoc()['count']
];

$recent_activity = $conn->query("
    SELECT al.*, u.full_name, CONCAT(p.first_name, ' ', p.last_name) as patient_name
    FROM lw_activity_log al
    JOIN lw_users u ON al.user_id = u.user_id
    JOIN lw_patient_visits v ON al.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    ORDER BY al.created_at DESC
    LIMIT 50
");

$visit_stats = $conn->query("
    SELECT visit_status, COUNT(*) as count 
    FROM lw_patient_visits 
    WHERE DATE(visit_date) = CURDATE()
    GROUP BY visit_status
");

include 'includes/header.php';
?>

<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));">
    <div class="stat-card">
        <div class="stat-label">Total Users</div>
        <div class="stat-value"><?php echo $stats['total_users']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Total Patients</div>
        <div class="stat-value"><?php echo $stats['total_patients']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Active Visits</div>
        <div class="stat-value"><?php echo $stats['active_visits']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Completed Today</div>
        <div class="stat-value"><?php echo $stats['completed_today']; ?></div>
    </div>
</div>

<div class="stats-grid">
    <div class="stat-card" style="border-left-color: #48bb78;">
        <div class="stat-label">Nurses</div>
        <div class="stat-value" style="color: #48bb78;"><?php echo $stats['nurses']; ?></div>
    </div>
    <div class="stat-card" style="border-left-color: #4299e1;">
        <div class="stat-label">Doctors</div>
        <div class="stat-value" style="color: #4299e1;"><?php echo $stats['doctors']; ?></div>
    </div>
    <div class="stat-card" style="border-left-color: #ed8936;">
        <div class="stat-label">Pharmacists</div>
        <div class="stat-value" style="color: #ed8936;"><?php echo $stats['pharmacists']; ?></div>
    </div>
    <div class="stat-card" style="border-left-color: #9f7aea;">
        <div class="stat-label">Diagnostic Staff</div>
        <div class="stat-value" style="color: #9f7aea;"><?php echo $stats['diagnostic_staff']; ?></div>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title"> Quick Access</h2>
    </div>
    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(250px, 1fr)); gap: 15px;">
        <a href="user_management.php" class="btn btn-primary" style="text-decoration: none; text-align: center; padding: 20px;">
            User Management
        </a>
        <a href="patient_lookup.php" class="btn btn-primary" style="text-decoration: none; text-align: center; padding: 20px;">
            Patient Lookup
        </a>
        <a href="activity_log.php" class="btn btn-primary" style="text-decoration: none; text-align: center; padding: 20px;">
             Activity Logs
        </a>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Today's Visit Status Distribution</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Status</th>
                    <th>Count</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $has_data = false;
                while ($stat = $visit_stats->fetch_assoc()): 
                    $has_data = true;
                ?>
                <tr>
                    <td><?php echo ucwords(str_replace('_', ' ', $stat['visit_status'])); ?></td>
                    <td><span class="badge badge-info"><?php echo $stat['count']; ?></span></td>
                </tr>
                <?php endwhile; ?>
                <?php if (!$has_data): ?>
                <tr>
                    <td colspan="2" style="text-align: center; color: var(--text-tertiary);">No visits today</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Recent System Activity</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Time</th>
                    <th>User</th>
                    <th>Patient</th>
                    <th>Action</th>
                    <th>Description</th>
                </tr>
            </thead>
            <tbody>
                <?php 
                $has_activity = false;
                while ($activity = $recent_activity->fetch_assoc()): 
                    $has_activity = true;
                ?>
                <tr>
                    <td><?php echo date('h:i A', strtotime($activity['created_at'])); ?></td>
                    <td><?php echo htmlspecialchars($activity['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($activity['patient_name']); ?></td>
                    <td><span class="badge badge-info"><?php echo ucwords(str_replace('_', ' ', $activity['action_type'])); ?></span></td>
                    <td><?php echo htmlspecialchars($activity['action_description']); ?></td>
                </tr>
                <?php endwhile; ?>
                <?php if (!$has_activity): ?>
                <tr>
                    <td colspan="5" style="text-align: center; color: var(--text-tertiary);">No recent activity</td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

</main>
</body>
</html>
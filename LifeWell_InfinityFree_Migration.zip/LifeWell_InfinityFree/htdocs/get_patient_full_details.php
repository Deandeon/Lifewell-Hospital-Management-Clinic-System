<?php
require_once 'config.php';
requireLogin();

if (!isset($_GET['patient_id'])) {
    die(json_encode(['error' => 'Patient ID required']));
}

$patient_id = intval($_GET['patient_id']); // logic

$patient_sql = "
    SELECT *, TIMESTAMPDIFF(YEAR, date_of_birth, CURDATE()) AS age
    FROM lw_patients
    WHERE patient_id = ?
";

$patient_stmt = $conn->prepare($patient_sql);
$patient_stmt->bind_param("i", $patient_id);
$patient_stmt->execute();

$patient_result = $patient_stmt->get_result();
$patient = $patient_result->fetch_assoc();

$patient_stmt->close();

if (!$patient) {
    die(json_encode(['error' => 'Patient not found']));
}

$visits_sql = "
    SELECT visit_id, visit_date, visit_status, priority, chief_complaint,
           DATE_FORMAT(visit_date, '%M %d, %Y %h:%i %p') AS formatted_date
    FROM lw_patient_visits
    WHERE patient_id = ?
    ORDER BY visit_date DESC
    LIMIT 20
";

$visits_stmt = $conn->prepare($visits_sql);
$visits_stmt->bind_param("i", $patient_id);
$visits_stmt->execute();

$visits_result = $visits_stmt->get_result();

$visits = [];
while ($visit = $visits_result->fetch_assoc()) {
    $visits[] = [
        'visit_date' => $visit['formatted_date'],
        'chief_complaint' => $visit['chief_complaint'],
        'visit_status' => str_replace('_', ' ', $visit['visit_status']),
        'priority' => $visit['priority']
    ];
}

$visits_stmt->close();

header('Content-Type: application/json');
echo json_encode([
    'patient' => $patient,
    'visits'  => $visits
]);
?>

<?php
session_start();
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY'] > 1800)) {
    session_unset();
    session_destroy();
    header('Location: login.php?timeout=1');
    exit();
    //timeout cookie destroyer ( added ffor extra protection and to prevent session hijacking)
}
$_SESSION['LAST_ACTIVITY'] = time();

if (!isset($_SESSION['CREATED'])) {
    $_SESSION['CREATED'] = time();
} else if (time() - $_SESSION['CREATED'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['CREATED'] = time();
}
// Fill these four values from InfinityFree Control Panel > MySQL Databases.
// Never upload real credentials to a public repository.
define('DB_HOST', 'REPLACE_WITH_INFINITYFREE_MYSQL_HOST');
define('DB_USER', 'REPLACE_WITH_INFINITYFREE_DATABASE_USERNAME');
define('DB_PASS', 'REPLACE_WITH_INFINITYFREE_DATABASE_PASSWORD');
define('DB_NAME', 'REPLACE_WITH_INFINITYFREE_DATABASE_NAME');


define('MAX_FILE_SIZE', 10485760); 
define('UPLOAD_DIR', __DIR__ . '/uploads/diagnostic_files/');
define('ALLOWED_EXTENSIONS', ['pdf', 'jpg', 'jpeg', 'png', 'dcm', 'doc', 'docx']);

if (!is_dir(UPLOAD_DIR)) {
    @mkdir(UPLOAD_DIR, 0755, true);
}
// Do not expose PHP warnings or filesystem/database paths to website visitors.
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

// Database connection
try {
    $conn = new mysqli(DB_HOST, DB_USER, DB_PASS, DB_NAME);
    
    if ($conn->connect_error) {
        error_log("LifeWell database connection failed: " . $conn->connect_error);
        http_response_code(500);
        exit("LifeWell is temporarily unavailable. Check the database settings in config.php.");
    }
    
    $conn->set_charset("utf8mb4");
} catch (Exception $e) {
    error_log("LifeWell database exception: " . $e->getMessage());
    http_response_code(500);
    exit("LifeWell is temporarily unavailable. Check the hosting error log.");
}

// Helpr FUNCTIONS

//login check
function isLoggedIn() {
    return isset($_SESSION['user_id']) && isset($_SESSION['role']);
}

// check role
function hasRole($role) {
    return isLoggedIn() && $_SESSION['role'] === $role;
}

// Redurect
function requireLogin() {
    if (!isLoggedIn()) {
        header('Location: login.php');
        exit();
    }
}

// sanitize input
function sanitize($data) {
    global $conn;
    return $conn->real_escape_string(trim($data));
}

// Auto patient code generator
function generatePatientCode($conn) {
    $result = $conn->query("SELECT COUNT(*) as count FROM lw_patients");
    $row = $result->fetch_assoc();
    $count = $row['count'] + 1;
    return 'PAT' . str_pad($count, 5, '0', STR_PAD_LEFT);
}

//  notification Creator
function createNotification($conn, $user_id, $visit_id, $title, $message, $type = 'info') {
    $stmt = $conn->prepare("INSERT INTO lw_notifications (user_id, visit_id, title, message, type) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("iisss", $user_id, $visit_id, $title, $message, $type);
    return $stmt->execute();
}

// activity Logger
function logActivity($conn, $visit_id, $user_id, $action_type, $description, $from_status = null, $to_status = null) {
    $stmt = $conn->prepare("INSERT INTO lw_activity_log (visit_id, user_id, action_type, action_description, from_status, to_status) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iissss", $visit_id, $user_id, $action_type, $description, $from_status, $to_status);
    return $stmt->execute();
}

// ile Validator
function validateFile($file) {
    $errors = [];
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors[] = "File upload error";
        return $errors;
    }
    
    if ($file['size'] > MAX_FILE_SIZE) {
        $errors[] = "File size exceeds maximum allowed (10MB)";
    }
    
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($extension, ALLOWED_EXTENSIONS)) {
        $errors[] = "File type not allowed. Allowed types: " . implode(', ', ALLOWED_EXTENSIONS);
    }
    
    return $errors;
}

//  upload file
function uploadDiagnosticFile($file, $result_id, $user_id) {
    global $conn;
    
    $errors = validateFile($file);
    if (!empty($errors)) {
        return ['success' => false, 'errors' => $errors];
    }
    $extension = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    $filename = 'diag_' . $result_id . '_' . time() . '_' . uniqid() . '.' . $extension;
    $filepath = UPLOAD_DIR . $filename;
    if (move_uploaded_file($file['tmp_name'], $filepath)) {
        $stmt = $conn->prepare("INSERT INTO lw_diagnostic_files (result_id, file_name, file_path, file_type, file_size, uploaded_by) VALUES (?, ?, ?, ?, ?, ?)");
        $original_name = $file['name'];
        $file_type = $file['type'];
        $file_size = $file['size'];
        $stored_path = 'uploads/diagnostic_files/' . $filename;
        $stmt->bind_param("isssii", $result_id, $original_name, $stored_path, $file_type, $file_size, $user_id);
        
        if ($stmt->execute()) {
            return ['success' => true, 'file_id' => $stmt->insert_id];
        } else {
            unlink($filepath);
            return ['success' => false, 'errors' => ['Database error']];
        }
    } else {
        return ['success' => false, 'errors' => ['Failed to upload file']];
    }
}
?>
<?php
require_once 'config.php';
requireLogin();

$page_title = 'Activity Log';


$date_filter = isset($_GET['date_filter']) ? sanitize($_GET['date_filter']) : 'today';
$custom_start = isset($_GET['start_date']) ? sanitize($_GET['start_date']) : '';
$custom_end = isset($_GET['end_date']) ? sanitize($_GET['end_date']) : '';

// Build date clause
$date_clause = '';
switch ($date_filter) {
    case 'today':
        $date_clause = "AND DATE(al.created_at) = CURDATE()";
        break;
    case 'yesterday':
        $date_clause = "AND DATE(al.created_at) = DATE_SUB(CURDATE(), INTERVAL 1 DAY)";
        break;
    case 'this_week':
        $date_clause = "AND YEARWEEK(al.created_at, 1) = YEARWEEK(CURDATE(), 1)";
        break;
    case 'last_week':
        $date_clause = "AND YEARWEEK(al.created_at, 1) = YEARWEEK(DATE_SUB(CURDATE(), INTERVAL 1 WEEK), 1)";
        break;
    case 'this_month':
        $date_clause = "AND MONTH(al.created_at) = MONTH(CURDATE()) AND YEAR(al.created_at) = YEAR(CURDATE())";
        break;
    case 'last_month':
        $date_clause = "AND MONTH(al.created_at) = MONTH(DATE_SUB(CURDATE(), INTERVAL 1 MONTH)) AND YEAR(al.created_at) = YEAR(DATE_SUB(CURDATE(), INTERVAL 1 MONTH))";
        break;
    case 'custom':
        if ($custom_start && $custom_end) {
            $date_clause = "AND DATE(al.created_at) BETWEEN '$custom_start' AND '$custom_end'";
        }
        break;
}

// Action type filter
$action_filter = isset($_GET['action_type']) ? sanitize($_GET['action_type']) : 'all';
$action_clause = $action_filter !== 'all' ? "AND al.action_type = '$action_filter'" : '';

// Get logs
$logs = $conn->query("
    SELECT al.*, 
           u.full_name as user_name, 
           u.role as user_role,
           CONCAT(p.first_name, ' ', p.last_name) as patient_name,
           p.patient_code,
           DATE_FORMAT(al.created_at, '%M %d, %Y %h:%i:%s %p') as formatted_date
    FROM lw_activity_log al
    JOIN lw_users u ON al.user_id = u.user_id
    JOIN lw_patient_visits v ON al.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    WHERE 1=1 $date_clause $action_clause
    ORDER BY al.created_at DESC
    LIMIT 1000
");


$total_logs = $logs->num_rows;

include 'includes/header.php';
?>

<style>
@media print {
    .no-print {
        display: none !important;
    }
    body {
        background: white !important;
    }
    .card {
        box-shadow: none !important;
        page-break-inside: avoid;
    }
}
</style>

<div class="card no-print">
    <div class="card-header">
        <h2 class="card-title">📋 Activity Log Viewer</h2>
    </div>
    
    <div style="background: var(--bg-tertiary); padding: 20px; border-radius: 8px; margin-bottom: 20px;">
        <form method="GET" style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
            <div class="form-group" style="margin: 0;">
                <label>Date Range</label>
                <select name="date_filter" id="dateFilter" onchange="toggleCustomDates()" style="width: 100%; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-primary); color: var(--text-primary);">
                    <option value="today" <?php echo $date_filter === 'today' ? 'selected' : ''; ?>>Today</option>
                    <option value="yesterday" <?php echo $date_filter === 'yesterday' ? 'selected' : ''; ?>>Yesterday</option>
                    <option value="this_week" <?php echo $date_filter === 'this_week' ? 'selected' : ''; ?>>This Week</option>
                    <option value="last_week" <?php echo $date_filter === 'last_week' ? 'selected' : ''; ?>>Last Week</option>
                    <option value="this_month" <?php echo $date_filter === 'this_month' ? 'selected' : ''; ?>>This Month</option>
                    <option value="last_month" <?php echo $date_filter === 'last_month' ? 'selected' : ''; ?>>Last Month</option>
                    <option value="custom" <?php echo $date_filter === 'custom' ? 'selected' : ''; ?>>Custom Range</option>
                </select>
            </div>
            
            <div class="form-group" style="margin: 0;" id="customDatesContainer" <?php echo $date_filter !== 'custom' ? 'style="display: none;"' : ''; ?>>
                <label>Start Date</label>
                <input type="date" name="start_date" value="<?php echo htmlspecialchars($custom_start); ?>" style="width: 100%; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-primary); color: var(--text-primary);">
            </div>
            
            <div class="form-group" style="margin: 0;" id="customDatesContainer2" <?php echo $date_filter !== 'custom' ? 'style="display: none;"' : ''; ?>>
                <label>End Date</label>
                <input type="date" name="end_date" value="<?php echo htmlspecialchars($custom_end); ?>" style="width: 100%; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-primary); color: var(--text-primary);">
            </div>
            
            <div class="form-group" style="margin: 0;">
                <label>Action Type</label>
                <select name="action_type" style="width: 100%; padding: 10px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-primary); color: var(--text-primary);">
                    <option value="all" <?php echo $action_filter === 'all' ? 'selected' : ''; ?>>All Actions</option>
                    <option value="nurse_intake" <?php echo $action_filter === 'nurse_intake' ? 'selected' : ''; ?>>Nurse Intake</option>
                    <option value="forward_to_doctor" <?php echo $action_filter === 'forward_to_doctor' ? 'selected' : ''; ?>>Forward to Doctor</option>
                    <option value="diagnosis" <?php echo $action_filter === 'diagnosis' ? 'selected' : ''; ?>>Diagnosis</option>
                    <option value="request_diagnostic" <?php echo $action_filter === 'request_diagnostic' ? 'selected' : ''; ?>>Request Diagnostic</option>
                    <option value="diagnostic_completed" <?php echo $action_filter === 'diagnostic_completed' ? 'selected' : ''; ?>>Diagnostic Completed</option>
                    <option value="prescribe" <?php echo $action_filter === 'prescribe' ? 'selected' : ''; ?>>Prescribe</option>
                    <option value="dispense" <?php echo $action_filter === 'dispense' ? 'selected' : ''; ?>>Dispense</option>
                </select>
            </div>
            
            <div style="display: flex; gap: 10px; align-items: flex-end;">
                <button type="submit" class="btn btn-primary">Apply Filters</button>
                <button type="button" onclick="exportToPDF()" class="btn btn-secondary">📄 Export PDF</button>
            </div>
        </form>
    </div>
</div>

<div class="card" id="logContent">
    <div class="card-header">
        <div>
            <h2 class="card-title">Activity Logs</h2>
            <p style="color: var(--text-tertiary); margin-top: 5px;">
                Showing <?php echo $total_logs; ?> log entries
                <?php 
                $filter_text = [
                    'today' => 'for today',
                    'yesterday' => 'for yesterday',
                    'this_week' => 'for this week',
                    'last_week' => 'for last week',
                    'this_month' => 'for this month',
                    'last_month' => 'for last month',
                    'custom' => $custom_start && $custom_end ? "from $custom_start to $custom_end" : ''
                ];
                echo $filter_text[$date_filter] ?? '';
                ?>
            </p>
        </div>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Date & Time</th>
                    <th>User</th>
                    <th>Role</th>
                    <th>Patient</th>
                    <th>Action</th>
                    <th>Description</th>
                    <th>Status Change</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($total_logs === 0): ?>
                    <tr><td colspan="7" style="text-align: center; padding: 20px; color: var(--text-tertiary);">No activity logs found for the selected period</td></tr>
                <?php endif; ?>
                <?php while ($log = $logs->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $log['formatted_date']; ?></td>
                    <td><?php echo htmlspecialchars($log['user_name']); ?></td>
                    <td><span class="badge badge-info"><?php echo ucfirst($log['user_role']); ?></span></td>
                    <td>
                        <strong><?php echo htmlspecialchars($log['patient_name']); ?></strong><br>
                        <small><?php echo htmlspecialchars($log['patient_code']); ?></small>
                    </td>
                    <td><span class="badge badge-<?php 
                        $colors = [
                            'nurse_intake' => 'info',
                            'forward_to_doctor' => 'info',
                            'diagnosis' => 'warning',
                            'request_diagnostic' => 'warning',
                            'diagnostic_completed' => 'success',
                            'prescribe' => 'warning',
                            'dispense' => 'success'
                        ];
                        echo $colors[$log['action_type']] ?? 'info';
                    ?>"><?php echo ucwords(str_replace('_', ' ', $log['action_type'])); ?></span></td>
                    <td><?php echo htmlspecialchars($log['action_description']); ?></td>
                    <td>
                        <?php if ($log['from_status'] && $log['to_status']): ?>
                            <span style="font-size: 0.85em;">
                                <?php echo ucwords(str_replace('_', ' ', $log['from_status'])); ?>
                                →
                                <?php echo ucwords(str_replace('_', ' ', $log['to_status'])); ?>
                            </span>
                        <?php else: ?>
                            <em style="color: var(--text-tertiary);">-</em>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/html2pdf.js/0.10.1/html2pdf.bundle.min.js"></script>

<script>
function toggleCustomDates() {
    const filter = document.getElementById('dateFilter').value;
    const container1 = document.getElementById('customDatesContainer');
    const container2 = document.getElementById('customDatesContainer2');
    
    if (filter === 'custom') {
        container1.style.display = 'block';
        container2.style.display = 'block';
    } else {
        container1.style.display = 'none';
        container2.style.display = 'none';
    }
}

function exportToPDF() {
    const now = new Date();
    const dateStr = now.getFullYear() + 
                   String(now.getMonth() + 1).padStart(2, '0') + 
                   String(now.getDate()).padStart(2, '0') + '_' +
                   String(now.getHours()).padStart(2, '0') + 
                   String(now.getMinutes()).padStart(2, '0') + 
                   String(now.getSeconds()).padStart(2, '0');
    
    const filename = 'log_' + dateStr + '.pdf';
    
   
    const element = document.getElementById('logContent').cloneNode(true);
    
    
    const header = document.createElement('div');
    header.style.textAlign = 'center';
    header.style.marginBottom = '20px';
    header.innerHTML = `
        <h1 style="color: #2a5298; margin-bottom: 5px;">LifeWell Hospital</h1>
        <h2 style="color: #666; font-size: 1.2em; margin-top: 0;">Activity Log Report</h2>
        <p style="color: #888;">Generated on ${now.toLocaleString()}</p>
        <hr style="border: 1px solid #ddd; margin: 15px 0;">
    `;
    element.insertBefore(header, element.firstChild);
    
 
    const opt = {
        margin: [10, 10, 10, 10],
        filename: filename,
        image: { type: 'jpeg', quality: 0.98 },
        html2canvas: { scale: 2, logging: false },
        jsPDF: { unit: 'mm', format: 'a4', orientation: 'landscape' }
    };
    
   
    const originalText = event.target.textContent;
    event.target.textContent = 'Generating PDF...';
    event.target.disabled = true;
    

    html2pdf().set(opt).from(element).save().then(() => {
        event.target.textContent = originalText;
        event.target.disabled = false;
    });
}
</script>

</main>
</body>
</html>
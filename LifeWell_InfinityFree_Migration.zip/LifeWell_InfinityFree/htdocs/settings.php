<?php
require_once 'config.php';
requireLogin();

$page_title = 'Settings';
$success = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['action']) && $_POST['action'] === 'update_profile') {
        $full_name = sanitize($_POST['full_name']);
        $email = sanitize($_POST['email']);
        $phone = sanitize($_POST['phone']);
        
        $stmt = $conn->prepare("UPDATE lw_users SET full_name = ?, email = ?, phone_number = ? WHERE user_id = ?");
        $stmt->bind_param("sssi", $full_name, $email, $phone, $_SESSION['user_id']);
        
        if ($stmt->execute()) {
            $_SESSION['full_name'] = $full_name;
            $_SESSION['email'] = $email;
            $_SESSION['phone'] = $phone;
            $success = "Profile updated successfully!";
        } else {
            $error = "Failed to update profile";
        }
    }
    
    if (isset($_POST['action']) && $_POST['action'] === 'change_password') {
        $current_password = $_POST['current_password'];
        $new_password = $_POST['new_password'];
        $confirm_password = $_POST['confirm_password'];
        
        if ($new_password !== $confirm_password) {
            $error = "New passwords do not match";
        } elseif (strlen($new_password) < 6) {
            $error = "Password must be at least 6 characters";
        } else {
            $result = $conn->query("SELECT password_hash FROM lw_users WHERE user_id = {$_SESSION['user_id']}");
            $user = $result->fetch_assoc();
            
            if (password_verify($current_password, $user['password_hash'])) {
                $new_hash = password_hash($new_password, PASSWORD_DEFAULT);
                $conn->query("UPDATE lw_users SET password_hash = '$new_hash' WHERE user_id = {$_SESSION['user_id']}");
                $success = "Password changed successfully!";
            } else {
                $error = "Current password is incorrect";
            }
        }
    }
}

$user_info = $conn->query("SELECT * FROM lw_users WHERE user_id = {$_SESSION['user_id']}")->fetch_assoc();

include 'includes/header.php';
?>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Profile Settings</h2>
    </div>
    <form method="POST">
        <input type="hidden" name="action" value="update_profile">
        <div class="form-group">
            <label>Full Name</label>
            <input type="text" name="full_name" value="<?php echo htmlspecialchars($user_info['full_name']); ?>" required>
        </div>
        <div class="form-group">
            <label>Email</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($user_info['email']); ?>" required>
        </div>
        <div class="form-group">
            <label>Phone Number</label>
            <input type="tel" name="phone" value="<?php echo htmlspecialchars($user_info['phone_number']); ?>" required>
        </div>
        <div class="form-group">
            <label>Username</label>
            <input type="text" value="<?php echo htmlspecialchars($user_info['username']); ?>" disabled>
        </div>
        <div class="form-group">
            <label>Role</label>
            <input type="text" value="<?php echo htmlspecialchars(ucfirst($user_info['role'])); ?>" disabled>
        </div>
        <button type="submit" class="btn btn-primary">Update Profile</button>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Change Password</h2>
    </div>
    <form method="POST">
        <input type="hidden" name="action" value="change_password">
        <div class="form-group">
            <label>Current Password</label>
            <input type="password" name="current_password" required>
        </div>
        <div class="form-group">
            <label>New Password</label>
            <input type="password" name="new_password" required minlength="6">
        </div>
        <div class="form-group">
            <label>Confirm New Password</label>
            <input type="password" name="confirm_password" required minlength="6">
        </div>
        <button type="submit" class="btn btn-primary">Change Password</button>
    </form>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Appearance</h2>
    </div>
    <div class="form-group">
        <label>Theme</label>
        <p style="color: var(--text-tertiary); margin-bottom: 15px;">Use the toggle in the header to switch between light and dark themes.</p>
        <div style="display: flex; align-items: center; gap: 15px;">
            <div style="padding: 20px; background: #f5f7fa; border-radius: 8px; flex: 1; text-align: center;">
                <div style="color: #2d3748; font-weight: 600;">Light Theme</div>
            </div>
            <div style="padding: 20px; background: #2d3748; border-radius: 8px; flex: 1; text-align: center;">
                <div style="color: #f7fafc; font-weight: 600;">Dark Theme</div>
            </div>
        </div>
    </div>
</div>

</main>
</body>
</html>


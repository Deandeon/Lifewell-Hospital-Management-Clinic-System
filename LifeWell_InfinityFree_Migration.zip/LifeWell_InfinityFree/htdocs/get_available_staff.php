<?php
require_once 'config.php';
requireLogin();

if (!isset($_GET['role'])) {
    die(json_encode(['error' => 'Role required']));
}

$role = sanitize($_GET['role']);

$sql = "
    SELECT user_id, full_name, email
    FROM lw_users
    WHERE role = ? AND is_active = TRUE
    ORDER BY full_name
";

$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $role);  
$stmt->execute();

$result = [];
$res = $stmt->get_result();

while ($row = $res->fetch_assoc()) {
    $result[] = $row;
}

$stmt->close();

header('Content-Type: application/json');
echo json_encode($result);
?>

<?php
require_once 'config.php';
requireLogin();

if (!isset($_GET['visit_id'])) {
    die(json_encode(['error' => 'Visit ID required']));
}

$visit_id = intval($_GET['visit_id']);

// Get visit 
$visit = $conn->query("
    SELECT v.*, p.*, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
           TIMESTAMPDIFF(YEAR, p.date_of_birth, CURDATE()) as age
    FROM lw_patient_visits v
    JOIN lw_patients p ON v.patient_id = p.patient_id
    WHERE v.visit_id = $visit_id
")->fetch_assoc();

//  vitals
$vitals = $conn->query("SELECT * FROM lw_vital_signs WHERE visit_id = $visit_id ORDER BY recorded_at DESC LIMIT 1")->fetch_assoc();

$response = [
    'visit' => [
        'visit_id' => $visit['visit_id'],
        'chief_complaint' => $visit['chief_complaint'],
        'priority' => $visit['priority']
    ],
    'patient' => [
        'name' => $visit['patient_name'],
        'code' => $visit['patient_code'],
        'age' => $visit['age'],
        'gender' => $visit['gender'],
        'blood_group' => $visit['blood_group'],
        'allergies' => $visit['allergies'],
        'medical_history' => $visit['medical_history']
    ],
    'vitals' => [
        'temperature' => $vitals['temperature'],
        'bp_systolic' => $vitals['blood_pressure_systolic'],
        'bp_diastolic' => $vitals['blood_pressure_diastolic'],
        'heart_rate' => $vitals['heart_rate'],
        'respiratory_rate' => $vitals['respiratory_rate'],
        'oxygen_saturation' => $vitals['oxygen_saturation'],
        'weight' => $vitals['weight'],
        'height' => $vitals['height'],
        'bmi' => round($vitals['bmi'], 1),
        'notes' => $vitals['notes']
    ]
];

header('Content-Type: application/json');
echo json_encode($response);
?>

<?php
require_once 'config.php';
requireLogin();

if (!isset($_GET['file_id'])) {
    die('File ID required');
}

$file_id = intval($_GET['file_id']);

// Get file info from database
$query = "SELECT * FROM lw_diagnostic_files WHERE file_id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $file_id);
$stmt->execute();
$result = $stmt->get_result();
$file = $result->fetch_assoc();
$stmt->close();

if (!$file) {
    die('File not found in database');
}


// Database dumps from Windows/Azure may contain absolute paths. Resolve only the
// stored basename inside this application's upload directory to avoid path traversal.
$storedName = basename(str_replace('\\', '/', (string)$file['file_path']));
$resolvedPath = UPLOAD_DIR . $storedName;
if ($storedName === '' || !is_file($resolvedPath) || !is_readable($resolvedPath)) {
    http_response_code(404);
    exit('File not found. If this is a migrated record, upload the file again.');
}


$download = isset($_GET['download']) ? true : false;


$extension = strtolower(pathinfo($file['file_name'], PATHINFO_EXTENSION));


$content_types = [
    'pdf' => 'application/pdf',
    'jpg' => 'image/jpeg',
    'jpeg' => 'image/jpeg',
    'png' => 'image/png',
    'gif' => 'image/gif',
    'doc' => 'application/msword',
    'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'dcm' => 'application/dicom',
    'txt' => 'text/plain'
];

$content_type = isset($content_types[$extension]) ? $content_types[$extension] : 'application/octet-stream';


if (ob_get_level()) {
    ob_end_clean();
}


header('Content-Type: ' . $content_type);
header('Content-Length: ' . filesize($resolvedPath));


if ($download || !in_array($extension, ['pdf', 'jpg', 'jpeg', 'png', 'gif', 'txt'])) {
    header('Content-Disposition: attachment; filename="' . $file['file_name'] . '"');
} else {
    header('Content-Disposition: inline; filename="' . $file['file_name'] . '"');
}


header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, max-age=3600');


readfile($resolvedPath);
exit;
?>
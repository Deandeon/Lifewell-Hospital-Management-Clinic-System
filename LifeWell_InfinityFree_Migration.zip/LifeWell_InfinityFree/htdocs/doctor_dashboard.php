<?php
require_once 'config.php';
requireLogin();

if (!hasRole('doctor')) {
    header('Location: dashboard.php');
    exit();
}

$page_title = 'Doctor Dashboard';
$success = '';
$error = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_consultation') {
    $visit_id = intval($_POST['visit_id']);
    $diagnosis = sanitize($_POST['diagnosis']);
    $treatment_plan = sanitize($_POST['treatment_plan']);
    $notes = sanitize($_POST['notes']);
    $requires_diagnostic = isset($_POST['requires_diagnostic']) ? 1 : 0;
    $requires_prescription = isset($_POST['requires_prescription']) ? 1 : 0;
    $diagnostic_staff_id = isset($_POST['diagnostic_staff_id']) && $_POST['diagnostic_staff_id'] ? intval($_POST['diagnostic_staff_id']) : 0;

    $stmt = $conn->prepare("INSERT INTO lw_consultations (visit_id, doctor_id, diagnosis, treatment_plan, notes, requires_diagnostic, requires_prescription, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $status = $requires_diagnostic ? 'awaiting_tests' : 'in_progress';
    $stmt->bind_param("iisssiss", $visit_id, $_SESSION['user_id'], $diagnosis, $treatment_plan, $notes, $requires_diagnostic, $requires_prescription, $status);
    
    if ($stmt->execute()) {
        $consultation_id = $stmt->insert_id;
    
        if ($requires_diagnostic) {
            if ($diagnostic_staff_id > 0) {
                $assigned_to = $diagnostic_staff_id;
            } else {
                $diag_staff = $conn->query("SELECT user_id FROM lw_users WHERE role = 'diagnostic' AND is_active = TRUE LIMIT 1");
                if ($diag_staff->num_rows > 0) {
                    $assigned_to = $diag_staff->fetch_assoc()['user_id'];
                } else {
                    $error = "No diagnostic staff available!";
                }
            }

            if (!$error && isset($assigned_to)) {
                
                $test_type = 'other';
                $test_description = 'Diagnostic tests required as per consultation';
                $urgency = 'routine';
                
                $stmt = $conn->prepare("INSERT INTO lw_diagnostic_requests (visit_id, consultation_id, requested_by, assigned_to, test_type, test_description, urgency, status) VALUES (?, ?, ?, ?, ?, ?, ?, 'pending')");
                $stmt->bind_param("iiiisss", $visit_id, $consultation_id, $_SESSION['user_id'], $assigned_to, $test_type, $test_description, $urgency);
                
                if ($stmt->execute()) {
                    
                    $conn->query("UPDATE lw_patient_visits SET visit_status = 'with_diagnostic', current_handler_id = $assigned_to WHERE visit_id = $visit_id");
                    
                    
                    $patient_info = $conn->query("SELECT CONCAT(p.first_name, ' ', p.last_name) as name FROM lw_patients p JOIN lw_patient_visits v ON p.patient_id = v.patient_id WHERE v.visit_id = $visit_id")->fetch_assoc();
                    createNotification($conn, $assigned_to, $visit_id, 'New Diagnostic Request', 'Diagnostic test requested for patient: ' . $patient_info['name'], 'info');
                    
                    logActivity($conn, $visit_id, $_SESSION['user_id'], 'request_diagnostic', "Diagnostic test requested", 'with_doctor', 'with_diagnostic');
                    
                    $success = "Consultation saved and sent to diagnostic team. You'll be notified when results are ready.";
                }
            } else {
                $error = "No diagnostic staff available!";
            }
        } 
       
        elseif ($requires_prescription) {
            logActivity($conn, $visit_id, $_SESSION['user_id'], 'diagnosis', 'Initial consultation completed - prescription pending', 'with_doctor', 'with_doctor');
            $success = "Consultation saved! Please create the prescription below.";
        }
        
        else {
            $conn->query("UPDATE lw_patient_visits SET visit_status = 'completed' WHERE visit_id = $visit_id");
            logActivity($conn, $visit_id, $_SESSION['user_id'], 'diagnosis', 'Consultation completed - no further action needed', 'with_doctor', 'completed');
            $success = "Consultation completed!";
        }
        
        if (!$error) {
            header('Location: doctor_dashboard.php?success=' . urlencode($success));
            exit();
        }
    } else {
        $error = "Failed to save consultation";
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'review_results') {
    $consultation_id = intval($_POST['consultation_id']);
    $visit_id = intval($_POST['visit_id']);
    $next_action = sanitize($_POST['next_action']);
    
    if ($next_action === 'prescription') {
        $conn->query("UPDATE lw_patient_visits SET visit_status = 'with_doctor', current_handler_id = {$_SESSION['user_id']} WHERE visit_id = $visit_id");
        $conn->query("UPDATE lw_consultations SET status = 'in_progress' WHERE consultation_id = $consultation_id");
        
        logActivity($conn, $visit_id, $_SESSION['user_id'], 'diagnosis', 'Diagnostic results reviewed - prescription needed', 'with_diagnostic', 'with_doctor');
        
        header('Location: doctor_dashboard.php?create_prescription=' . $consultation_id . '&visit_id=' . $visit_id);
        exit();
    } else {
        $conn->query("UPDATE lw_patient_visits SET visit_status = 'completed' WHERE visit_id = $visit_id");
        $conn->query("UPDATE lw_consultations SET status = 'completed' WHERE consultation_id = $consultation_id");
        
        logActivity($conn, $visit_id, $_SESSION['user_id'], 'diagnosis', 'Consultation completed after diagnostic review', 'with_diagnostic', 'completed');
        
        header('Location: doctor_dashboard.php?success=Visit completed successfully');
        exit();
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_prescription') {
    $visit_id = intval($_POST['visit_id']);
    $consultation_id = intval($_POST['consultation_id']);
    $notes = sanitize($_POST['prescription_notes']);
    $pharmacist_id = isset($_POST['pharmacist_id']) && $_POST['pharmacist_id'] ? intval($_POST['pharmacist_id']) : 0;
    
    $stmt = $conn->prepare("INSERT INTO lw_prescriptions (visit_id, consultation_id, doctor_id, notes, status) VALUES (?, ?, ?, ?, 'pending')");
    $stmt->bind_param("iiis", $visit_id, $consultation_id, $_SESSION['user_id'], $notes);
    
    if ($stmt->execute()) {
        $prescription_id = $stmt->insert_id;
        
        if (isset($_POST['medications']) && is_array($_POST['medications'])) {
            foreach ($_POST['medications'] as $med) {
                if (empty($med['name'])) continue;
                
                $med_name = sanitize($med['name']);
                $dosage = sanitize($med['dosage']);
                $frequency = sanitize($med['frequency']);
                $duration = sanitize($med['duration']);
                $quantity = intval($med['quantity']);
                $instructions = sanitize($med['instructions']);
                
                $stmt = $conn->prepare("INSERT INTO lw_prescription_items (prescription_id, medication_name, dosage, frequency, duration, quantity, instructions) VALUES (?, ?, ?, ?, ?, ?, ?)");
                $stmt->bind_param("issssis", $prescription_id, $med_name, $dosage, $frequency, $duration, $quantity, $instructions);
                $stmt->execute();
            }
        }
        
       
        if ($pharmacist_id > 0) {
            $pharm_user_id = $pharmacist_id;
        } else {
            $pharm_result = $conn->query("SELECT user_id FROM lw_users WHERE role = 'pharmacist' AND is_active = TRUE LIMIT 1");
            if ($pharm_result->num_rows > 0) {
                $pharm_user_id = $pharm_result->fetch_assoc()['user_id'];
            }
        }
        
        if (isset($pharm_user_id)) {
            $conn->query("UPDATE lw_patient_visits SET visit_status = 'with_pharmacy', current_handler_id = $pharm_user_id WHERE visit_id = $visit_id");
            
            $patient_info = $conn->query("SELECT CONCAT(p.first_name, ' ', p.last_name) as name FROM lw_patients p JOIN lw_patient_visits v ON p.patient_id = v.patient_id WHERE v.visit_id = $visit_id")->fetch_assoc();
            createNotification($conn, $pharm_user_id, $visit_id, 'New Prescription', 'Prescription ready for dispensing: ' . $patient_info['name'], 'info');
            
            logActivity($conn, $visit_id, $_SESSION['user_id'], 'prescribe', 'Prescription created and forwarded to pharmacy', 'with_doctor', 'with_pharmacy');
        }
        
        $conn->query("UPDATE lw_consultations SET status = 'completed' WHERE consultation_id = $consultation_id");
        
        header('Location: doctor_dashboard.php?success=Prescription created and sent to pharmacy');
        exit();
    }
}


$active_visits = $conn->query("
    SELECT v.*, p.*, CONCAT(p.first_name, ' ', p.last_name) as patient_name,
           vs.temperature, vs.blood_pressure_systolic, vs.blood_pressure_diastolic,
           vs.heart_rate, vs.respiratory_rate, vs.oxygen_saturation, vs.weight, vs.height, vs.bmi, vs.notes as vital_notes
    FROM lw_patient_visits v 
    JOIN lw_patients p ON v.patient_id = p.patient_id 
    LEFT JOIN lw_vital_signs vs ON v.visit_id = vs.visit_id
    WHERE v.visit_status = 'with_doctor' AND v.current_handler_id = {$_SESSION['user_id']}
    ORDER BY v.priority DESC, v.created_at ASC
");

// Get visits awaiting test results
$awaiting_tests = $conn->query("
    SELECT 
        v.visit_id,
        p.patient_code,
        CONCAT(p.first_name, ' ', p.last_name) AS patient_name,
        c.consultation_id,
        c.diagnosis,
        c.treatment_plan,
        COUNT(DISTINCT dr.request_id) AS total_tests,
        COUNT(DISTINCT CASE WHEN dr.status = 'completed' THEN dr.request_id END) AS completed_tests
    FROM lw_diagnostic_requests dr
    JOIN lw_consultations c ON dr.consultation_id = c.consultation_id
    JOIN lw_patient_visits v ON c.visit_id = v.visit_id
    JOIN lw_patients p ON v.patient_id = p.patient_id
    WHERE c.doctor_id = {$_SESSION['user_id']}
    GROUP BY c.consultation_id
    HAVING completed_tests = total_tests
    ORDER BY MAX(dr.completion_date) DESC
");


// Get stats
$stats = [
    'pending_consultations' => $conn->query("SELECT COUNT(*) as count FROM lw_patient_visits WHERE visit_status = 'with_doctor' AND current_handler_id = {$_SESSION['user_id']}")->fetch_assoc()['count'],
    'awaiting_results' => $conn->query("SELECT COUNT(DISTINCT v.visit_id) as count FROM lw_patient_visits v JOIN lw_consultations c ON v.visit_id = c.visit_id WHERE c.doctor_id = {$_SESSION['user_id']} AND v.visit_status = 'with_diagnostic' AND c.status = 'awaiting_tests'")->fetch_assoc()['count'],
    'completed_today' => $conn->query("SELECT COUNT(*) as count FROM lw_consultations WHERE doctor_id = {$_SESSION['user_id']} AND DATE(consultation_date) = CURDATE()")->fetch_assoc()['count']
];

include 'includes/header.php';

if (isset($_GET['success'])) {
    echo '<div class="alert alert-success">' . htmlspecialchars($_GET['success']) . '</div>';
}

if (isset($_GET['create_prescription']) && isset($_GET['visit_id'])) {
    $consultation_id = intval($_GET['create_prescription']);
    $visit_id = intval($_GET['visit_id']);
    
    echo '<script>
        window.addEventListener("DOMContentLoaded", function() {
            proceedToPrescription(' . $visit_id . ', ' . $consultation_id . ');
        });
    </script>';
}
?>

<div class="stats-grid">
    <div class="stat-card">
        <div class="stat-label">Pending Consultations</div>
        <div class="stat-value"><?php echo $stats['pending_consultations']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Awaiting Test Results</div>
        <div class="stat-value"><?php echo $stats['awaiting_results']; ?></div>
    </div>
    <div class="stat-card">
        <div class="stat-label">Completed Today</div>
        <div class="stat-value"><?php echo $stats['completed_today']; ?></div>
    </div>
</div>

<div style="margin-bottom: 20px;">
    <a href="patient_lookup.php" class="btn btn-secondary">Patient Lookup</a>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">Pending Consultations</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Patient</th>
                    <th>Age/Gender</th>
                    <th>Chief Complaint</th>
                    <th>Vital Signs</th>
                    <th>Priority</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($active_visits->num_rows === 0): ?>
                    <tr><td colspan="6" style="text-align: center; padding: 20px; color: var(--text-tertiary);">No pending consultations</td></tr>
                <?php endif; ?>
                <?php while ($visit = $active_visits->fetch_assoc()): 
                    $age = date_diff(date_create($visit['date_of_birth']), date_create('now'))->y;
                ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($visit['patient_name']); ?></strong><br>
                        <small><?php echo htmlspecialchars($visit['patient_code']); ?></small>
                    </td>
                    <td><?php echo $age; ?>Y / <?php echo $visit['gender']; ?></td>
                    <td><?php echo htmlspecialchars($visit['chief_complaint']); ?></td>
                    <td>
                        <?php if ($visit['temperature']): ?>
                            Temp: <?php echo $visit['temperature']; ?>°C<br>
                            BP: <?php echo $visit['blood_pressure_systolic']; ?>/<?php echo $visit['blood_pressure_diastolic']; ?><br>
                            HR: <?php echo $visit['heart_rate']; ?> bpm<br>
                            SpO2: <?php echo $visit['oxygen_saturation']; ?>%
                        <?php else: ?>
                            <em>No vitals recorded</em>
                        <?php endif; ?>
                    </td>
                    <td><span class="badge badge-<?php echo $visit['priority'] === 'emergency' ? 'danger' : ($visit['priority'] === 'urgent' ? 'warning' : 'info'); ?>"><?php echo ucfirst($visit['priority']); ?></span></td>
                    <td>
                        <button onclick="viewPatient(<?php echo $visit['visit_id']; ?>)" class="btn btn-primary">Consult</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">🔬 Diagnostic Results Ready for Review</h2>
    </div>
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Patient</th>
                    <th>Diagnosis</th>
                    <th>Tests Status</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($awaiting_tests->num_rows === 0): ?>
                    <tr><td colspan="4" style="text-align: center; padding: 20px; color: var(--text-tertiary);">No results awaiting review</td></tr>
                <?php endif; ?>
                <?php while ($visit = $awaiting_tests->fetch_assoc()): ?>
                <tr>
                    <td>
                        <strong><?php echo htmlspecialchars($visit['patient_name']); ?></strong><br>
                        <small><?php echo htmlspecialchars($visit['patient_code']); ?></small>
                    </td>
                    <td><?php echo htmlspecialchars($visit['diagnosis']); ?></td>
                    <td>
                        <span class="badge badge-success">
                            ✓ All <?php echo $visit['total_tests']; ?> test(s) completed
                        </span>
                    </td>
                    <td>
                        <button onclick="reviewDiagnosticResults(<?php echo $visit['visit_id']; ?>, <?php echo $visit['consultation_id']; ?>)" class="btn btn-primary">Review Results</button>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>

<!-- Consultation  -->
<div id="consultationModal" class="modal">
    <div class="modal-content" style="max-width: 900px;">
        <div class="modal-header">
            <h2>Patient Consultation</h2>
            <button class="modal-close" onclick="closeModal('consultationModal')">&times;</button>
        </div>
        <div id="patientData"></div>
    </div>
</div>

<script>
let currentVisitData = null;

function viewPatient(visitId) {
    fetch('get_visit_details.php?visit_id=' + visitId)
        .then(res => res.json())
        .then(data => {
            currentVisitData = data;
            displayPatientInfo(data);
            showModal('consultationModal');
        });
}

function displayPatientInfo(data) {
    // Update( david) - now they can choose no more auto assign.
    Promise.all([
        fetch('get_available_staff.php?role=diagnostic').then(r => r.json()),
        fetch('get_available_staff.php?role=pharmacist').then(r => r.json())
    ]).then(([diagStaff, pharmacists]) => {
        const diagOptions = diagStaff.map(s => 
            `<option value="${s.user_id}">${s.full_name}</option>`
        ).join('');
        
        const pharmOptions = pharmacists.map(s => 
            `<option value="${s.user_id}">${s.full_name}</option>`
        ).join('');
        
        const html = `
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                <div>
                    <h3>Patient Information</h3>
                    <p><strong>Name:</strong> ${data.patient.name}</p>
                    <p><strong>Code:</strong> ${data.patient.code}</p>
                    <p><strong>Age/Gender:</strong> ${data.patient.age}Y / ${data.patient.gender}</p>
                    <p><strong>Blood Group:</strong> ${data.patient.blood_group || 'N/A'}</p>
                    <p><strong>Allergies:</strong> ${data.patient.allergies || 'None'}</p>
                    <p><strong>Medical History:</strong> ${data.patient.medical_history || 'None'}</p>
                </div>
                <div>
                    <h3>Vital Signs</h3>
                    <p><strong>Temperature:</strong> ${data.vitals.temperature}°C</p>
                    <p><strong>Blood Pressure:</strong> ${data.vitals.bp_systolic}/${data.vitals.bp_diastolic} mmHg</p>
                    <p><strong>Heart Rate:</strong> ${data.vitals.heart_rate} bpm</p>
                    <p><strong>Respiratory Rate:</strong> ${data.vitals.respiratory_rate} /min</p>
                    <p><strong>SpO2:</strong> ${data.vitals.oxygen_saturation}%</p>
                    <p><strong>Weight:</strong> ${data.vitals.weight} kg</p>
                    <p><strong>Height:</strong> ${data.vitals.height} cm</p>
                    <p><strong>BMI:</strong> ${data.vitals.bmi}</p>
                    ${data.vitals.notes ? '<p><strong>Nurse Notes:</strong> ' + data.vitals.notes + '</p>' : ''}
                </div>
            </div>
            <div style="background: var(--bg-tertiary); padding: 15px; border-radius: 8px; margin-bottom: 20px;">
                <strong>Chief Complaint:</strong> ${data.visit.chief_complaint}
            </div>
            <form method="POST">
                <input type="hidden" name="action" value="create_consultation">
                <input type="hidden" name="visit_id" value="${data.visit.visit_id}">
                <div class="form-group">
                    <label>Diagnosis *</label>
                    <textarea name="diagnosis" rows="3" required placeholder="Enter diagnosis..."></textarea>
                </div>
                <div class="form-group">
                    <label>Treatment Plan *</label>
                    <textarea name="treatment_plan" rows="4" required placeholder="Enter treatment plan..."></textarea>
                </div>
                <div class="form-group">
                    <label>Additional Notes</label>
                    <textarea name="notes" rows="3" placeholder="Additional observations..."></textarea>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="requires_diagnostic" id="requiresDiagnostic" onchange="toggleDiagnosticStaff()">
                        Requires Diagnostic Tests
                    </label>
                </div>
                <div class="form-group" id="diagnosticStaffSelect" style="display: none;">
                    <label>Assign to Diagnostic Staff</label>
                    <select name="diagnostic_staff_id">
                        <option value="">Auto-assign to available staff</option>
                        ${diagOptions}
                    </select>
                </div>
                <div class="form-group">
                    <label style="display: flex; align-items: center; gap: 10px;">
                        <input type="checkbox" name="requires_prescription" id="requiresPrescription" onchange="togglePharmacistSelect()">
                        Will Require Prescription (after tests if applicable)
                    </label>
                </div>
                <div class="form-group" id="pharmacistSelectContainer" style="display: none;">
                    <label>Assign to Pharmacist (for later)</label>
                    <select name="pharmacist_id" id="pharmacistSelect">
                        <option value="">Auto-assign to available pharmacist</option>
                        ${pharmOptions}
                    </select>
                </div>
                <button type="submit" class="btn btn-primary">Save Consultation</button>
            </form>
        `;
        document.getElementById('patientData').innerHTML = html;
    });
}

function toggleDiagnosticStaff() {
    const checkbox = document.getElementById('requiresDiagnostic');
    const select = document.getElementById('diagnosticStaffSelect');
    select.style.display = checkbox.checked ? 'block' : 'none';
}

function togglePharmacistSelect() {
    const checkbox = document.getElementById('requiresPrescription');
    const container = document.getElementById('pharmacistSelectContainer');
    container.style.display = checkbox.checked ? 'block' : 'none';
}

function reviewDiagnosticResults(visitId, consultationId) {
    console.log('Fetching diagnostic results for consultation:', consultationId);
    
    fetch('get_diagnostic_results.php?consultation_id=' + consultationId)
        .then(res => {
            console.log('Response status:', res.status);
            if (!res.ok) {
                throw new Error('Network response was not ok: ' + res.status);
            }
            return res.json();
        })
        .then(data => {
            console.log('Received data:', data);
            if (data.error) {
                alert('Error: ' + data.error);
                return;
            }
            displayDiagnosticReview(data, visitId, consultationId);
            showModal('consultationModal');
        })
        .catch(error => {
            console.error('Error fetching diagnostic results:', error);
            alert('Failed to load diagnostic results. Check console for details.');
        });
}

function displayDiagnosticReview(data, visitId, consultationId) {
    console.log('=== DISPLAY DIAGNOSTIC REVIEW ===');
    console.log('Full data received:', JSON.stringify(data, null, 2));
    
    if (!data || data.error) {
        alert('Error loading results: ' + (data.error || 'Unknown error'));
        console.error('Error in data:', data);
        return;
    }
    
    if (!data.results || data.results.length === 0) {
        alert('No diagnostic results found! Total results: ' + (data.total_results || 0));
        console.warn('No results in data');
        return;
    }
    
    console.log('Processing ' + data.results.length + ' results');
    
    let resultsHtml = '';
    data.results.forEach((result, index) => {
        console.log('--- Result ' + (index + 1) + ' ---');
        console.log('Test Type:', result.test_type);
        console.log('Has Result:', result.has_result);
        console.log('Status:', result.status);
        console.log('Files count:', result.files ? result.files.length : 0);
        console.log('Result data:', result);
        
      
        let filesHtml = '';
        if (result.files && result.files.length > 0) {
            console.log('Building files HTML for ' + result.files.length + ' files');
            filesHtml = `
                <div style="margin-top: 15px; padding: 15px; background: var(--bg-secondary); border-radius: 6px; border-top: 2px solid var(--info);">
                    <strong style="color: var(--accent-primary);">📎 Attached Files (${result.files.length}):</strong><br>
                    <div style="margin-top: 10px; display: flex; flex-wrap: wrap; gap: 10px;">
            `;
            
            result.files.forEach((file, fileIndex) => {
                console.log('File ' + (fileIndex + 1) + ':', file.file_name, '(ID: ' + file.file_id + ')');
                filesHtml += `
                    <a href="view_file.php?file_id=${file.file_id}" 
                       target="_blank" 
                       class="btn btn-secondary" 
                       style="margin: 0; padding: 10px 15px; text-decoration: none; display: inline-flex; align-items: center; gap: 8px;"
                       title="Download ${file.file_name}">
                        📄 ${file.file_name}
                        <small style="opacity: 0.7;">(${file.file_size})</small>
                    </a>
                `;
            });
            
            filesHtml += '</div></div>';
        } else {
            console.log('No files for this result');
            filesHtml = '<div style="margin-top: 10px; padding: 10px; background: var(--bg-tertiary); border-radius: 6px; color: var(--text-tertiary);"><em>No files attached to this test</em></div>';
        }

        //  result card
        const statusBadgeColor = result.status === 'completed' ? 'success' : 'warning';
        const borderColor = result.has_result ? 'var(--success)' : 'var(--warning)';
        
        resultsHtml += `
            <div style="background: var(--bg-primary); padding: 20px; border-radius: 10px; margin-bottom: 20px; border-left: 5px solid ${borderColor}; box-shadow: 0 2px 8px var(--shadow);">
                <div style="display: flex; justify-content: space-between; align-items: start; margin-bottom: 15px;">
                    <h4 style="margin: 0; color: var(--accent-primary); font-size: 1.2em;">🔬 ${result.test_type}</h4>
                    <span class="badge badge-${statusBadgeColor}" style="font-size: 0.9em;">${result.status.toUpperCase()}</span>
                </div>
                
                <div style="background: var(--bg-secondary); padding: 12px; border-radius: 6px; margin-bottom: 12px;">
                    <strong>Test Description:</strong><br>
                    <span style="color: var(--text-secondary);">${result.test_description}</span>
                </div>
                
                ${result.result_date ? '<p style="color: var(--text-tertiary); margin: 8px 0;"><strong>Completed:</strong> ' + result.result_date + '</p>' : ''}
                
                ${result.result_summary ? `
                    <div style="background: var(--bg-secondary); padding: 15px; border-radius: 6px; margin: 12px 0; border-left: 3px solid var(--info);">
                        <strong style="color: var(--accent-primary);">📋 Summary:</strong><br>
                        <p style="margin: 8px 0 0 0; line-height: 1.6;">${result.result_summary}</p>
                    </div>
                ` : ''}
                
                ${result.findings ? `
                    <div style="background: var(--bg-secondary); padding: 15px; border-radius: 6px; margin: 12px 0; border-left: 3px solid var(--success);">
                        <strong style="color: var(--success);">🔍 Findings:</strong><br>
                        <p style="margin: 8px 0 0 0; line-height: 1.6;">${result.findings}</p>
                    </div>
                ` : ''}
                
                ${result.recommendations ? `
                    <div style="background: #fff3cd; padding: 15px; border-radius: 6px; margin: 12px 0; border-left: 3px solid #ffc107;">
                        <strong style="color: #856404;">💡 Recommendations:</strong><br>
                        <p style="margin: 8px 0 0 0; color: #856404; line-height: 1.6;">${result.recommendations}</p>
                    </div>
                ` : ''}
                
                ${filesHtml}
            </div>
        `;
    });
    
    const html = `
        <div style="max-height: 80vh; overflow-y: auto; padding-right: 10px;">
            <h3 style="color: var(--accent-primary); margin-bottom: 20px; font-size: 1.5em; display: flex; align-items: center; gap: 10px;">
                 Diagnostic Results Review
                <span class="badge badge-info" style="font-size: 0.7em;">${data.results.length} Test(s)</span>
            </h3>
            
            <div style="background: linear-gradient(135deg, var(--bg-tertiary) 0%, var(--bg-secondary) 100%); padding: 20px; border-radius: 10px; margin-bottom: 25px; border-left: 5px solid var(--accent-primary);">
                <p style="margin: 5px 0;"><strong> Patient:</strong> ${data.patient_name}</p>
                <p style="margin: 5px 0;"><strong> Initial Diagnosis:</strong> ${data.diagnosis}</p>
                ${data.treatment_plan ? '<p style="margin: 5px 0;"><strong> Treatment Plan:</strong> ' + data.treatment_plan + '</p>' : ''}
                ${data.consultation_notes ? '<p style="margin: 5px 0;"><strong> Notes:</strong> ' + data.consultation_notes + '</p>' : ''}
            </div>
            
            <h4 style="margin: 25px 0 15px 0; color: var(--text-primary); font-size: 1.2em;">Test Results & Reports:</h4>
            
            ${resultsHtml}
            
            <div style="background: #fff3cd; padding: 20px; border-radius: 10px; border-left: 5px solid #856404; margin: 25px 0;">
                <strong style="font-size: 1.1em;"> What would you like to do next?</strong>
                <p style="color: #856404; margin: 10px 0 0 0; font-size: 0.95em;">Review the diagnostic results above and choose your next action.</p>
            </div>
            
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px; margin-top: 20px;">
                <form method="POST" style="margin: 0;">
                    <input type="hidden" name="action" value="review_results">
                    <input type="hidden" name="consultation_id" value="${consultationId}">
                    <input type="hidden" name="visit_id" value="${visitId}">
                    <input type="hidden" name="next_action" value="prescription">
                    <button type="submit" class="btn btn-primary" style="width: 100%; padding: 15px; font-size: 1.05em;">
                         Write Prescription For paitient
                    </button>
                </form>
                <form method="POST" style="margin: 0;">
                    <input type="hidden" name="action" value="review_results">
                    <input type="hidden" name="consultation_id" value="${consultationId}">
                    <input type="hidden" name="visit_id" value="${visitId}">
                    <input type="hidden" name="next_action" value="complete">
                    <button type="submit" class="btn btn-secondary" style="width: 100%; padding: 15px; font-size: 1.05em;">
                        ✓ Complete Visit
                    </button>
                </form>
            </div>
        </div>
    `;
    
    document.getElementById('patientData').innerHTML = html;
}

function proceedToPrescription(visitId, consultationId) {
    
    fetch('get_available_staff.php?role=pharmacist')
        .then(r => r.json())
        .then(pharmacists => {
            const pharmOptions = pharmacists.map(s => 
                `<option value="${s.user_id}">${s.full_name}</option>`
            ).join('');
            
            const html = `
                <h3> Create Prescription</h3>
                <form method="POST" id="prescriptionForm">
                    <input type="hidden" name="action" value="create_prescription">
                    <input type="hidden" name="visit_id" value="${visitId}">
                    <input type="hidden" name="consultation_id" value="${consultationId}">
                    
                    <div class="form-group">
                        <label>Assign to Pharmacist</label>
                        <select name="pharmacist_id">
                            <option value="">Auto-assign to available pharmacist</option>
                            ${pharmOptions}
                        </select>
                    </div>
                    
                    <div id="medicationsContainer">
                        <div class="medication-item" style="background: var(--bg-tertiary); padding: 15px; border-radius: 8px; margin-bottom: 15px;">
                            <div class="form-group">
                                <label>Medication Name *</label>
                                <input type="text" name="medications[0][name]" required>
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                <div class="form-group">
                                    <label>Dosage *</label>
                                    <input type="text" name="medications[0][dosage]" required placeholder="e.g., 500mg">
                                </div>
                                <div class="form-group">
                                    <label>Frequency *</label>
                                    <input type="text" name="medications[0][frequency]" required placeholder="e.g., Twice daily">
                                </div>
                            </div>
                            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                                <div class="form-group">
                                    <label>Duration *</label>
                                    <input type="text" name="medications[0][duration]" required placeholder="e.g., 7 days">
                                </div>
                                <div class="form-group">
                                    <label>Quantity *</label>
                                    <input type="number" name="medications[0][quantity]" required placeholder="e.g., 14">
                                </div>
                            </div>
                            <div class="form-group">
                                <label>Instructions</label>
                                <textarea name="medications[0][instructions]" rows="2" placeholder="e.g., Take after meals"></textarea>
                            </div>
                        </div>
                    </div>
                    <button type="button" onclick="addMedication()" class="btn btn-secondary">+ Add Another Medication</button>
                    <div class="form-group" style="margin-top: 20px;">
                        <label>Prescription Notes</label>
                        <textarea name="prescription_notes" rows="3" placeholder="Additional instructions for pharmacist..."></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">✓ Create & Send to Pharmacy</button>
                </form>
            `;
            document.getElementById('patientData').innerHTML = html;
            showModal('consultationModal');
        });
}

let medicationCount = 1;
function addMedication() {
    const container = document.getElementById('medicationsContainer');
    const html = `
        <div class="medication-item" style="background: var(--bg-tertiary); padding: 15px; border-radius: 8px; margin-bottom: 15px;">
            <div class="form-group">
                <label>Medication Name *</label>
                <input type="text" name="medications[${medicationCount}][name]" required>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label>Dosage *</label>
                    <input type="text" name="medications[${medicationCount}][dosage]" required placeholder="e.g., 500mg">
                </div>
                <div class="form-group">
                    <label>Frequency *</label>
                    <input type="text" name="medications[${medicationCount}][frequency]" required placeholder="e.g., Twice daily">
                </div>
            </div>
            <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 10px;">
                <div class="form-group">
                    <label>Duration *</label>
                    <input type="text" name="medications[${medicationCount}][duration]" required placeholder="e.g., 7 days">
                </div>
                <div class="form-group">
                    <label>Quantity *</label>
                    <input type="number" name="medications[${medicationCount}][quantity]" required placeholder="e.g., 14">
                </div>
            </div>
            <div class="form-group">
                <label>Instructions</label>
                <textarea name="medications[${medicationCount}][instructions]" rows="2" placeholder="e.g., Take after meals"></textarea>
            </div>
        </div>
    `;
    container.insertAdjacentHTML('beforeend', html);
    medicationCount++;
}
</script>

</main>
</body>
</html>
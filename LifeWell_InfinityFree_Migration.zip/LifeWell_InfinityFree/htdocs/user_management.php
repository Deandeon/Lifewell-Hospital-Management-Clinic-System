<?php
require_once 'config.php';
requireLogin();

if (!hasRole('admin')) {
    header('Location: dashboard.php');
    exit();
}

$page_title = 'User Management';
$success = '';
$error = '';


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'create_user') {
    $username = sanitize($_POST['username']);
    $email = sanitize($_POST['email']);
    $password = $_POST['password'];
    $full_name = sanitize($_POST['full_name']);
    $phone = sanitize($_POST['phone']);
    $role = sanitize($_POST['role']);
    
 
    $check = $conn->query("SELECT user_id FROM lw_users WHERE username = '$username' OR email = '$email'");
    if ($check->num_rows > 0) {
        $error = "Username or email already exists";
    } else {
        $password_hash = password_hash($password, PASSWORD_DEFAULT);
        $stmt = $conn->prepare("INSERT INTO lw_users (username, email, password_hash, full_name, phone_number, role) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->bind_param("ssssss", $username, $email, $password_hash, $full_name, $phone, $role);
        
        if ($stmt->execute()) {
            $success = "User created successfully!";
            header('Location: user_management.php?success=created');
            exit();
        } else {
            $error = "Failed to create user";
        }
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_user') {
    $user_id = intval($_POST['user_id']);
    $email = sanitize($_POST['email']);
    $full_name = sanitize($_POST['full_name']);
    $phone = sanitize($_POST['phone']);
    $role = sanitize($_POST['role']);
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    
    $stmt = $conn->prepare("UPDATE lw_users SET email = ?, full_name = ?, phone_number = ?, role = ?, is_active = ? WHERE user_id = ?");
    $stmt->bind_param("ssssii", $email, $full_name, $phone, $role, $is_active, $user_id);
    
    if ($stmt->execute()) {
        header('Location: user_management.php?success=updated');
        exit();
    } else {
        $error = "Failed to update user";
    }
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'reset_password') {
    $user_id = intval($_POST['user_id']);
    $new_password = $_POST['new_password'];
    
    $password_hash = password_hash($new_password, PASSWORD_DEFAULT);
    $conn->query("UPDATE lw_users SET password_hash = '$password_hash' WHERE user_id = $user_id");
    
    header('Location: user_management.php?success=password_reset');
    exit();
}


if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'delete_user') {
    $user_id = intval($_POST['user_id']);
    $conn->query("UPDATE lw_users SET is_active = 0 WHERE user_id = $user_id");
    
    header('Location: user_management.php?success=deleted');
    exit();
}


$filter_role = isset($_GET['role']) ? sanitize($_GET['role']) : 'all';
$where_clause = $filter_role !== 'all' ? "WHERE role = '$filter_role'" : '';

$users = $conn->query("SELECT * FROM lw_users $where_clause ORDER BY role, full_name");


$stats = [
    'nurses' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'nurse' AND is_active = TRUE")->fetch_assoc()['count'],
    'doctors' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'doctor' AND is_active = TRUE")->fetch_assoc()['count'],
    'pharmacists' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'pharmacist' AND is_active = TRUE")->fetch_assoc()['count'],
    'diagnostic' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'diagnostic' AND is_active = TRUE")->fetch_assoc()['count'],
    'admins' => $conn->query("SELECT COUNT(*) as count FROM lw_users WHERE role = 'admin' AND is_active = TRUE")->fetch_assoc()['count'],
];

include 'includes/header.php';

if (isset($_GET['success'])) {
    $messages = [
        'created' => 'User created successfully!',
        'updated' => 'User updated successfully!',
        'password_reset' => 'Password reset successfully!',
        'deleted' => 'User deactivated successfully!'
    ];
    $success = $messages[$_GET['success']] ?? 'Action completed successfully!';
}
?>

<div class="stats-grid" style="grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));">
    <div class="stat-card" style="border-left-color: #48bb78;">
        <div class="stat-label">Nurses</div>
        <div class="stat-value" style="color: #48bb78;"><?php echo $stats['nurses']; ?></div>
    </div>
    <div class="stat-card" style="border-left-color: #4299e1;">
        <div class="stat-label">Doctors</div>
        <div class="stat-value" style="color: #4299e1;"><?php echo $stats['doctors']; ?></div>
    </div>
    <div class="stat-card" style="border-left-color: #ed8936;">
        <div class="stat-label">Pharmacists</div>
        <div class="stat-value" style="color: #ed8936;"><?php echo $stats['pharmacists']; ?></div>
    </div>
    <div class="stat-card" style="border-left-color: #9f7aea;">
        <div class="stat-label">Diagnostic</div>
        <div class="stat-value" style="color: #9f7aea;"><?php echo $stats['diagnostic']; ?></div>
    </div>
    <div class="stat-card" style="border-left-color: #f56565;">
        <div class="stat-label">Admins</div>
        <div class="stat-value" style="color: #f56565;"><?php echo $stats['admins']; ?></div>
    </div>
</div>

<?php if ($success): ?>
    <div class="alert alert-success"><?php echo htmlspecialchars($success); ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert alert-danger"><?php echo htmlspecialchars($error); ?></div>
<?php endif; ?>

<div class="card">
    <div class="card-header">
        <h2 class="card-title">User Management</h2>
        <div style="display: flex; gap: 10px; align-items: center;">
            <select onchange="window.location.href='user_management.php?role='+this.value" style="padding: 8px 12px; border: 2px solid var(--border-color); border-radius: 8px; background: var(--bg-primary); color: var(--text-primary);">
                <option value="all" <?php echo $filter_role === 'all' ? 'selected' : ''; ?>>All Roles</option>
                <option value="nurse" <?php echo $filter_role === 'nurse' ? 'selected' : ''; ?>>Nurses</option>
                <option value="doctor" <?php echo $filter_role === 'doctor' ? 'selected' : ''; ?>>Doctors</option>
                <option value="pharmacist" <?php echo $filter_role === 'pharmacist' ? 'selected' : ''; ?>>Pharmacists</option>
                <option value="diagnostic" <?php echo $filter_role === 'diagnostic' ? 'selected' : ''; ?>>Diagnostic Staff</option>
                <option value="admin" <?php echo $filter_role === 'admin' ? 'selected' : ''; ?>>Administrators</option>
            </select>
            <button onclick="showModal('createUserModal')" class="btn btn-primary">+ Create New User</button>
        </div>
    </div>
    
    <div class="table-container">
        <table>
            <thead>
                <tr>
                    <th>Username</th>
                    <th>Full Name</th>
                    <th>Email</th>
                    <th>Phone</th>
                    <th>Role</th>
                    <th>Status</th>
                    <th>Created</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($user = $users->fetch_assoc()): ?>
                <tr style="<?php echo !$user['is_active'] ? 'opacity: 0.5;' : ''; ?>">
                    <td><strong><?php echo htmlspecialchars($user['username']); ?></strong></td>
                    <td><?php echo htmlspecialchars($user['full_name']); ?></td>
                    <td><?php echo htmlspecialchars($user['email']); ?></td>
                    <td><?php echo htmlspecialchars($user['phone_number']); ?></td>
                    <td><span class="badge badge-info"><?php echo ucfirst($user['role']); ?></span></td>
                    <td>
                        <span class="badge badge-<?php echo $user['is_active'] ? 'success' : 'danger'; ?>">
                            <?php echo $user['is_active'] ? 'Active' : 'Inactive'; ?>
                        </span>
                    </td>
                    <td><?php echo date('M d, Y', strtotime($user['created_at'])); ?></td>
                    <td>
                        <button onclick="editUser(<?php echo htmlspecialchars(json_encode($user)); ?>)" class="btn btn-secondary" style="padding: 6px 12px; margin: 2px;">Edit</button>
                        <button onclick="resetPassword(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')" class="btn btn-secondary" style="padding: 6px 12px; margin: 2px;">Reset Password</button>
                        <?php if ($user['user_id'] != $_SESSION['user_id']): ?>
                            <button onclick="deleteUser(<?php echo $user['user_id']; ?>, '<?php echo htmlspecialchars($user['username']); ?>')" class="btn btn-danger" style="padding: 6px 12px; margin: 2px;">Deactivate</button>
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</div>


<div id="createUserModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Create New User</h2>
            <button class="modal-close" onclick="closeModal('createUserModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="create_user">
            <div class="form-group">
                <label>Username *</label>
                <input type="text" name="username" required pattern="[a-zA-Z0-9_]{3,20}">
            </div>
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="full_name" required>
            </div>
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" required>
            </div>
            <div class="form-group">
                <label>Phone Number *</label>
                <input type="tel" name="phone" required>
            </div>
            <div class="form-group">
                <label>Role *</label>
                <select name="role" required>
                    <option value="nurse">Nurse</option>
                    <option value="doctor">Doctor</option>
                    <option value="pharmacist">Pharmacist</option>
                    <option value="diagnostic">Diagnostic Staff</option>
                    <option value="admin">Administrator</option>
                </select>
            </div>
            <div class="form-group">
                <label>Password *</label>
                <input type="password" name="password" required minlength="6">
            </div>
            <button type="submit" class="btn btn-primary">Create User</button>
        </form>
    </div>
</div>


<div id="editUserModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Edit User</h2>
            <button class="modal-close" onclick="closeModal('editUserModal')">&times;</button>
        </div>
        <form method="POST" id="editUserForm">
            <input type="hidden" name="action" value="update_user">
            <input type="hidden" name="user_id" id="edit_user_id">
            <div class="form-group">
                <label>Username</label>
                <input type="text" id="edit_username" disabled style="background: var(--bg-tertiary);">
            </div>
            <div class="form-group">
                <label>Full Name *</label>
                <input type="text" name="full_name" id="edit_full_name" required>
            </div>
            <div class="form-group">
                <label>Email *</label>
                <input type="email" name="email" id="edit_email" required>
            </div>
            <div class="form-group">
                <label>Phone Number *</label>
                <input type="tel" name="phone" id="edit_phone" required>
            </div>
            <div class="form-group">
                <label>Role *</label>
                <select name="role" id="edit_role" required>
                    <option value="nurse">Nurse</option>
                    <option value="doctor">Doctor</option>
                    <option value="pharmacist">Pharmacist</option>
                    <option value="diagnostic">Diagnostic Staff</option>
                    <option value="admin">Administrator</option>
                </select>
            </div>
            <div class="form-group">
                <label style="display: flex; align-items: center; gap: 10px;">
                    <input type="checkbox" name="is_active" id="edit_is_active">
                    Active
                </label>
            </div>
            <button type="submit" class="btn btn-primary">Update User</button>
        </form>
    </div>
</div>


<div id="resetPasswordModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h2>Reset Password</h2>
            <button class="modal-close" onclick="closeModal('resetPasswordModal')">&times;</button>
        </div>
        <form method="POST">
            <input type="hidden" name="action" value="reset_password">
            <input type="hidden" name="user_id" id="reset_user_id">
            <div id="reset_username_display" style="background: var(--bg-tertiary); padding: 12px; border-radius: 8px; margin-bottom: 15px;"></div>
            <div class="form-group">
                <label>New Password *</label>
                <input type="password" name="new_password" required minlength="6">
            </div>
            <button type="submit" class="btn btn-primary">Reset Password</button>
        </form>
    </div>
</div>

<script>
function editUser(user) {
    document.getElementById('edit_user_id').value = user.user_id;
    document.getElementById('edit_username').value = user.username;
    document.getElementById('edit_full_name').value = user.full_name;
    document.getElementById('edit_email').value = user.email;
    document.getElementById('edit_phone').value = user.phone_number;
    document.getElementById('edit_role').value = user.role;
    document.getElementById('edit_is_active').checked = user.is_active == 1;
    showModal('editUserModal');
}

function resetPassword(userId, username) {
    document.getElementById('reset_user_id').value = userId;
    document.getElementById('reset_username_display').innerHTML = '<strong>Resetting password for:</strong> ' + username;
    showModal('resetPasswordModal');
}

function deleteUser(userId, username) {
    if (confirm('Are you sure you want to deactivate user: ' + username + '?')) {
        const form = document.createElement('form');
        form.method = 'POST';
        form.innerHTML = `
            <input type="hidden" name="action" value="delete_user">
            <input type="hidden" name="user_id" value="${userId}">
        `;
        document.body.appendChild(form);
        form.submit();
    }
}
</script>

</main>
</body>
</html>